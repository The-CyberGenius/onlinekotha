document.addEventListener('DOMContentLoaded', () => {
    const chatContainer = document.getElementById('chat-container');
    const scrollArea = document.getElementById('chat-scroll-area');
    const headerName = document.getElementById('chat-header-name');
    const headerAvatar = document.getElementById('header-avatar');
    const sidebarAvatar = document.getElementById('sidebar-avatar');
    const sidebarTitle = document.getElementById('sidebar-title');
    const statsInfo = document.getElementById('stats-info');
    const searchBox = document.getElementById('search-box');
    const searchActionBtn = document.getElementById('search-action-btn');
    const searchClearBtn = document.getElementById('search-clear-btn');
    const resultsList = document.getElementById('results-list');

    // Search Modal Elements
    const searchModal = document.getElementById('search-modal');
    const closeSearchModalBtn = document.getElementById('close-search-modal');
    const searchModalResults = document.getElementById('search-modal-results');
    const searchModalStats = document.getElementById('search-modal-stats');

    const closeSearchModal = () => {
        if (!searchModal) return;
        searchModal.classList.remove('opacity-100');
        searchModal.classList.add('opacity-0');
        setTimeout(() => {
            searchModal.classList.add('hidden');
        }, 300);
    };

    if (closeSearchModalBtn) {
        closeSearchModalBtn.addEventListener('click', closeSearchModal);
    }
    if (searchModal) {
        searchModal.addEventListener('click', (e) => {
            if (e.target === searchModal) closeSearchModal();
        });
    }

    // Quick buttons
    const btnTop = document.getElementById('btn-top');
    const btnBottom = document.getElementById('btn-bottom');
    const btnMedia = document.getElementById('btn-media');

    // Mobile Sidebar Elements
    const sidebar = document.getElementById('sidebar');
    const openSidebarBtn = document.getElementById('open-sidebar-btn');
    const closeSidebarBtn = document.getElementById('close-sidebar-btn');

    // Modal Elements
    const mediaModal = document.getElementById('media-modal');
    const closeModal = document.getElementById('close-modal');
    const modalContent = document.getElementById('modal-content');

    const btnAnalytics = document.getElementById('btn-analytics');
    const analyticsModal = document.getElementById('analytics-modal');
    const closeAnalytics = document.getElementById('close-analytics');
    const dynamicHeaderDate = document.getElementById('dynamic-header-date');

    let allMessages = [];
    let displayedMessages = [];
    let otherPersonName = "Contact";
    let myName = null;
    let currentChat = '';
    let datePartsOrder = { monthIdx: 0, dayIdx: 1 }; // default MM/DD/YY

    // View state
    let renderStart = 0;
    let renderEnd = 0;
    const CHUNK_SIZE = 100;

    // Smart name cleaning — used everywhere names are displayed
    function cleanDisplayName(raw) {
        if (!raw) return '';
        let n = raw;
        // Strip WhatsApp prefixes
        n = n.replace(/^whatsapp[\s_-]*chat[\s_-]*(with[\s_-]*)?[-–—]?\s*/i, '');
        // Underscores → spaces
        n = n.replace(/_/g, ' ');
        // Trailing dates/numbers/junk
        n = n.replace(/[\s-]*\(?\d{4,}\)?[\s-]*$/g, '');
        n = n.replace(/[\s-]*\d{1,2}[\s/-]\d{1,2}[\s/-]\d{2,4}\s*$/g, '');
        n = n.replace(/[\s-]+\d+\s*$/g, '');
        n = n.replace(/\.(txt|zip|csv|json)\s*$/i, '');
        // Collapse spaces + trim
        n = n.replace(/\s{2,}/g, ' ').trim();
        // Title case
        if (n) n = n.replace(/\b\w+/g, w => w.charAt(0).toUpperCase() + w.slice(1));
        return n;
    }

    function isGarbageName(s) {
        if (!s) return true;
        const cleaned = s.replace(/[\s\-_+().]/g, '').toLowerCase();
        if (/^(user|contact|unknown|friend|you|me|myself|chat|group|whatsapp|whatsappchat)$/i.test(cleaned)) return true;
        // Mostly digits (phone numbers)
        const digitRatio = (cleaned.replace(/\D/g, '').length) / cleaned.length;
        if (digitRatio > 0.5) return true;
        if (cleaned.length < 2) return true;
        return false;
    }

    function resolveChatNames(folderName, senders) {
        const senderNames = senders.map(s => s[0]);
        const cleanedFolder = cleanDisplayName(folderName);

        let detectedMyName = "";
        let detectedOtherName = "";

        // 1. Try to find "me" based on logged-in user email or name if available
        if (window.__USER__ && window.__USER__.email) {
            const emailPrefix = window.__USER__.email.split('@')[0].toLowerCase();
            // Look for a sender name that matches email prefix
            const matchedMe = senderNames.find(name => {
                const n = name.toLowerCase().replace(/[^a-z0-9]/g, '');
                return n.includes(emailPrefix) || emailPrefix.includes(n);
            });
            if (matchedMe) {
                detectedMyName = matchedMe;
            }
        }

        // 2. Try to find "me" based on common self-names
        if (!detectedMyName) {
            const selfName = senderNames.find(name => /^(you|me|myself)$/i.test(name));
            if (selfName) detectedMyName = selfName;
        }

        // 3. Match folder name to senders to find the other person
        if (cleanedFolder && !isGarbageName(cleanedFolder)) {
            const matchedOther = senderNames.find(name => {
                const n = name.toLowerCase().replace(/[^a-z0-9]/g, '');
                const f = cleanedFolder.toLowerCase().replace(/[^a-z0-9]/g, '');
                return n.includes(f) || f.includes(n);
            });
            if (matchedOther) {
                detectedOtherName = matchedOther;
            } else {
                detectedOtherName = cleanedFolder;
            }
        }

        // If we found "me", then the other person is the sender who is not "me"
        if (detectedMyName && !detectedOtherName) {
            detectedOtherName = senderNames.find(name => name !== detectedMyName) || "";
        }

        // If we found "other", then "me" is the sender who is not "other"
        if (detectedOtherName && !detectedMyName) {
            detectedMyName = senderNames.find(name => name !== detectedOtherName) || "";
        }

        // Fallbacks if still unresolved
        if (!detectedOtherName) {
            if (cleanedFolder && !isGarbageName(cleanedFolder)) {
                detectedOtherName = cleanedFolder;
            } else if (senderNames.length > 2) {
                detectedOtherName = (cleanedFolder && !isGarbageName(cleanedFolder)) 
                    ? `${cleanedFolder} (Group)` 
                    : `Group Chat (${senderNames.length} members)`;
            } else {
                detectedOtherName = senderNames[1] || senderNames[0] || "User";
            }
        }
        if (!detectedMyName) {
            detectedMyName = senderNames.find(name => name !== detectedOtherName) || senderNames[0] || "User";
        }

        return { myName: detectedMyName, otherName: detectedOtherName };
    }


    const closeMod = () => {
        mediaModal.classList.remove('opacity-100');
        mediaModal.classList.add('opacity-0');
        setTimeout(() => {
            mediaModal.classList.add('hidden');
            modalContent.innerHTML = '';
        }, 300);
    };

    closeModal.addEventListener('click', closeMod);
    mediaModal.addEventListener('click', (e) => {
        if (e.target === mediaModal) closeMod();
    });

    const getStringColor = (str, forceDark) => {
        const isDark = forceDark !== undefined ? forceDark : document.documentElement.classList.contains('dark');
        let hash = 0;
        for (let i = 0; i < str.length; i++) hash = str.charCodeAt(i) + ((hash << 5) - hash);
        let color = '#';
        for (let i = 0; i < 3; i++) {
            let value = (hash >> (i * 8)) & 0xFF;
            value = isDark ? (value % 100) + 155 : (value % 200) + 30;
            color += ('00' + value.toString(16)).substr(-2);
        }
        return color;
    };

    // Sidebar toggle — true = open, false = close, undefined = toggle
    const toggleSidebar = (open) => {
        if (window.innerWidth >= 768 && !window.kothaCompact) return; // mobile OR compact desktop frame
        const backdrop = document.getElementById('sidebar-backdrop');
        if (open === true) {
            sidebar.classList.remove('-translate-x-full');
            if (backdrop) backdrop.classList.remove('hidden');
        } else if (open === false) {
            sidebar.classList.add('-translate-x-full');
            if (backdrop) backdrop.classList.add('hidden');
        } else {
            sidebar.classList.toggle('-translate-x-full');
            if (backdrop) backdrop.classList.toggle('hidden');
        }
    };

    // Expose for other modules
    window.kothaSidebarOpen = () => toggleSidebar(true);
    window.kothaSidebarClose = () => toggleSidebar(false);

    document.getElementById('open-sidebar-btn').addEventListener('click', () => toggleSidebar(true));
    document.getElementById('close-sidebar-btn').addEventListener('click', () => toggleSidebar(false));
    const sidebarBackdrop = document.getElementById('sidebar-backdrop');
    if (sidebarBackdrop) sidebarBackdrop.addEventListener('click', () => toggleSidebar(false));

    // Swipe left to close sidebar
    let sidebarTouchStartX = 0;
    sidebar.addEventListener('touchstart', e => {
        if (e.touches.length > 1) return;
        sidebarTouchStartX = e.touches[0].clientX;
    }, {passive: true});
    sidebar.addEventListener('touchend', e => {
        const deltaX = e.changedTouches[0].clientX - sidebarTouchStartX;
        if (deltaX < -50) { // Swiped left by 50px
            toggleSidebar(false);
        }
    });

    // Swipe right from left edge to open sidebar
    let edgeTouchStartX = 0;
    let edgeTouchStartY = 0;
    document.addEventListener('touchstart', e => {
        if (e.touches.length > 1) return;
        edgeTouchStartX = e.touches[0].clientX;
        edgeTouchStartY = e.touches[0].clientY;
    }, {passive: true});
    document.addEventListener('touchend', e => {
        const deltaX = e.changedTouches[0].clientX - edgeTouchStartX;
        const deltaY = Math.abs(e.changedTouches[0].clientY - edgeTouchStartY);
        if (edgeTouchStartX < 30 && deltaX > 50 && deltaY < 50) {
            toggleSidebar(true);
        }
    });

    // Desktop sidebar collapse/expand
    const collapseBtn = document.getElementById('collapse-sidebar-btn');
    const collapseIcon = document.getElementById('collapse-icon');
    if (collapseBtn) {
        const savedState = localStorage.getItem('kotha_sidebar_collapsed');
        if (savedState === '1') {
            sidebar.classList.add('sidebar-collapsed');
            if (collapseIcon) collapseIcon.style.transform = 'rotate(180deg)';
        }
        collapseBtn.addEventListener('click', () => {
            const collapsed = sidebar.classList.toggle('sidebar-collapsed');
            if (collapseIcon) collapseIcon.style.transform = collapsed ? 'rotate(180deg)' : '';
            localStorage.setItem('kotha_sidebar_collapsed', collapsed ? '1' : '0');
        });
    }

    const mobileFilterBtn = document.getElementById('mobile-filter-btn');
    if (mobileFilterBtn) {
        mobileFilterBtn.addEventListener('click', () => {
            // Force open the sidebar
            if (window.innerWidth < 768) {
                sidebar.classList.remove('-translate-x-full');
                const backdrop = document.getElementById('sidebar-backdrop');
                if (backdrop) backdrop.classList.remove('hidden');
            }
            const container = document.getElementById('smart-filters-container');
            container.classList.remove('hidden'); // Focus filters
        });
    }

    function kothaLinkify(text) {
        if (!text) return '';
        const esc = String(text).replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
        }[c]));
        const urlRegex = /(https?:\/\/[^\s<]+|www\.[^\s<]+)/gi;
        return esc.replace(urlRegex, (url) => {
            const href = url.toLowerCase().startsWith('www.') ? `http://${url}` : url;
            return `<a href="${href}" target="_blank" rel="noopener noreferrer" class="chat-link" onclick="event.stopPropagation()">${url}</a>`;
        });
    }
    window.kothaLinkify = kothaLinkify;

    const renderMessage = (msg, index, isConsecutive = false) => {
        const isMe = msg.sender === myName;

        let mediaHtml = '';
        if (msg.attachment && msg.type !== 'system') {
            const fileUrl = `/media/${encodeURIComponent(currentChat)}/${encodeURIComponent(msg.attachment)}`;

            if (msg.type === 'image') {
                mediaHtml = `
                    <div class="relative group/media overflow-hidden rounded-2xl border border-black/10 dark:border-white/10 bg-black/5 dark:bg-white/5 p-1.5 shadow-sm backdrop-blur-sm transition-all duration-300 hover:shadow-md hover:border-indigo-400/50 w-[240px] sm:w-[260px] h-[220px] sm:h-[240px] flex flex-col justify-between mb-1" onclick="openImageModal('${fileUrl}')">
                        <div class="relative overflow-hidden rounded-xl bg-white/80 dark:bg-black/40 flex items-center justify-center flex-1 w-full p-2.5">
                            <img src="${fileUrl}" loading="lazy" class="w-full h-full object-contain rounded-lg cursor-zoom-in transition-transform duration-300 group-hover/media:scale-105" alt="Image" onerror="this.onerror=null;this.src='/favicon.svg';">
                        </div>
                    </div>
                `;
            } else if (msg.type === 'video') {
                const vext = (msg.attachment.split('.').pop() || '').toLowerCase();
                // .mov = server sends video/mp4 (same H.264 container, Chrome can play it)
                // .mkv / .avi may not play in browser — show player + download fallback
                const browserPlayable = ['mp4', 'mov', 'm4v', 'webm', '3gp'].includes(vext);
                const vmime = vext === 'webm' ? 'video/webm'
                    : vext === '3gp' ? 'video/3gpp'
                    : 'video/mp4';
                mediaHtml = `
                    <div class="relative z-10 pointer-events-auto mb-1">
                        ${browserPlayable ? `
                        <video controls playsinline preload="metadata" class="w-64 max-w-full rounded-xl shadow-md border border-white/20 bg-black"
                            onerror="this.style.display='none';this.nextElementSibling.style.display='block'">
                            <source src="${fileUrl}" type="${vmime}">
                        </video>
                        <a href="${fileUrl}" target="_blank" download style="display:none" class="block text-[11px] font-bold ${isMe ? 'opacity-70' : 'text-indigo-500'} hover:underline mt-1">⬇ Can't play — Download video</a>
                        ` : `
                        <div class="w-64 h-16 rounded-xl bg-black/30 flex items-center justify-center text-xs text-gray-400">
                            <span>📹 ${escH(msg.attachment.split('/').pop() || 'video')}</span>
                        </div>
                        `}
                        <a href="${fileUrl}" target="_blank" download class="block text-[11px] font-bold ${isMe ? 'opacity-70' : 'text-indigo-500'} hover:underline mt-1">⬇ Download video</a>
                    </div>
                `;
            } else if (msg.type === 'audio') {
                mediaHtml = `
                    <div class="mb-2">
                        <audio controls preload="metadata" class="h-10 w-64 max-w-full rounded-xl shadow-sm ${isMe ? 'opacity-90' : 'opacity-100'}">
                            <source src="${fileUrl}" type="audio/mpeg">
                        </audio>
                    </div>
                `;
            } else {
                mediaHtml = `
                    <div class="flex items-center ${isMe ? 'doc-me' : 'doc-them'} p-3 rounded-xl gap-3 cursor-pointer hover:opacity-80 transition mb-1 border">
                        <div class="w-10 h-10 ${isMe ? 'doc-icon-me' : 'doc-icon-them'} rounded-lg flex items-center justify-center font-bold text-xs">DOC</div>
                        <div class="overflow-hidden">
                            <p class="text-sm font-semibold truncate">${msg.attachment}</p>
                            <a href="${fileUrl}" target="_blank" download class="text-xs font-bold uppercase hover:underline ${isMe ? 'opacity-70' : 'text-indigo-500'}">Download</a>
                        </div>
                    </div>
                `;
            }
        }

        let msgClass = isMe ? 'glass-chat-me ml-auto rounded-2xl rounded-tr-sm' : 'glass-chat-them mr-auto rounded-2xl rounded-tl-sm';
        if (isConsecutive) {
            msgClass = isMe ? 'glass-chat-me ml-auto rounded-2xl rounded-tr-md rounded-br-sm' : 'glass-chat-them mr-auto rounded-2xl rounded-tl-md rounded-bl-sm';
        }

        let nameHtml = '';
        if (!isMe && !isConsecutive) {
            nameHtml = `<p class="sender-name text-[11px] font-bold mb-1 tracking-wide" style="color: ${getStringColor(msg.sender)}">${msg.sender}</p>`;
        }

        let contentHtml = '';
        if (msg.text) {
            const onlyEmojis = /^[\u{1f300}-\u{1f5ff}\u{1f900}-\u{1f9ff}\u{1f600}-\u{1f64f}\u{1f680}-\u{1f6ff}\u{2600}-\u{26ff}\u{2700}-\u{27bf}\u{1f1e6}-\u{1f1ff}\u{1f191}-\u{1f251}\u{1f004}\u{1f0cf}\u{1f170}-\u{1f171}\u{1f17e}-\u{1f17f}\u{1f18e}\u{3030}\u{2b50}\u{2b55}\u{2934}-\u{2935}\u{2b05}-\u{2b07}\u{2b1b}-\u{2b1c}\u{3297}\u{3299}\u{303d}\u{00a9}\u{00ae}\u{2122}\u{23f3}\u{24c2}\u{23e9}-\u{23ef}\u{25b6}\u{23f8}-\u{23fa}\s]+$/gu;
            const isBigEmoji = msg.text.trim().length > 0 && msg.text.trim().length <= 6 && onlyEmojis.test(msg.text);
            contentHtml = `<p style="color:var(--msg-text)" class="${isBigEmoji ? 'text-4xl' : 'text-[14px]'} leading-normal font-medium whitespace-pre-wrap break-words select-text">${isBigEmoji ? msg.text : kothaLinkify(msg.text)}</p>`;
        }
        if (msg.type === 'system') {
            return `
            <div class="flex justify-center mb-4" id="msg-${msg.id}">
                <div class="glass-panel text-gray-600 text-[11px] px-4 py-2 font-medium rounded-full shadow-sm truncate max-w-xs md:max-w-md">
                    ${msg.text || msg.attachment}
                </div>
            </div>`;
        }

        const timeVar = isMe ? '--msg-time-me' : '--msg-time-them';
        const topMargin = isConsecutive ? 'mt-0.5' : 'mt-2';

        return `
            <div class="flex flex-col mb-1 w-full ${topMargin}" id="msg-${msg.id}">
                <div class="max-w-[80%] md:max-w-[70%] lg:max-w-[65%] relative px-3 py-1.5 md:px-3.5 md:py-2 ${msgClass} flex flex-col gap-0.5">
                    ${nameHtml}
                    ${mediaHtml}
                    ${contentHtml}
                    <div style="color:var(${timeVar})" class="text-[10px] flex items-center justify-end font-semibold mt-1 ml-auto select-none pt-0.5">
                        ${msg.time}
                        ${isMe ? `<svg class="w-3.5 h-3.5 ml-1 text-blue-500" width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7" /></svg>` : ''}
                    </div>
                </div>
            </div>
        `;
    };

    window.openImageModal = (url) => {
        mediaModal.classList.remove('hidden');
        void mediaModal.offsetWidth;
        mediaModal.classList.remove('opacity-0');
        mediaModal.classList.add('opacity-100');
        modalContent.innerHTML = `<img src="${url}" class="max-w-full max-h-[85vh] object-contain rounded-2xl shadow-2xl border-4 border-white/20">`;
    };

    // ---------- Date formatting ----------
    function formatChatDate(raw) {
        if (!raw) return '';
        let d;
        if (raw.includes('-')) {
            // YYYY-MM-DD format (ISO style from desktop regex)
            const parts = raw.split('-');
            if (parts.length === 3) {
                d = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
            }
        } else if (raw.includes('/')) {
            // DD/MM/YY format (Indian WhatsApp style)
            const parts = raw.split('/');
            if (parts.length === 3) {
                const day = parseInt(parts[0]);
                const month = parseInt(parts[1]);
                let year = parts[2].length === 2 ? 2000 + parseInt(parts[2]) : parseInt(parts[2]);
                d = new Date(year, month - 1, day);
                // Fallback to MM/DD/YY if the parsed date is in the future
                if (d > new Date()) {
                    const altD = new Date(year, day - 1, month);
                    if (altD <= new Date()) {
                        d = altD;
                    }
                }
            }
        }
        if (!d || isNaN(d.getTime())) return raw;
        return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
    }

    let lastRenderedDate = '';

    const generateChatsHtml = (snippet) => {
        const frag = document.createDocumentFragment();
        snippet.forEach((msg, idx) => {
            if (msg.date && msg.date !== lastRenderedDate) {
                const dateSep = document.createElement('div');
                dateSep.className = 'flex justify-center mb-6 w-full date-separator';
                dateSep.setAttribute('data-date', msg.date);
                dateSep.innerHTML = `<span class="bg-[#E1F2FB] dark:bg-[#182229] text-[#54656f] dark:text-[#8696a0] text-[12.5px] px-3 py-1 rounded-lg shadow-sm font-medium">${formatChatDate(msg.date)}</span>`;
                frag.appendChild(dateSep);
                lastRenderedDate = msg.date;
            }
            let isConsecutive = false;
            if (idx > 0) {
                const prevMsg = snippet[idx - 1];
                if (prevMsg.sender === msg.sender && prevMsg.type !== 'system' && msg.type !== 'system' && prevMsg.date === msg.date) {
                    isConsecutive = true;
                }
            }
            const wrapper = document.createElement('div');
            wrapper.innerHTML = renderMessage(msg, idx, isConsecutive);
            while (wrapper.firstChild) frag.appendChild(wrapper.firstChild);
        });
        return frag;
    };

    const renderChats = (startIndex, endIndex, mode = 'reset') => {
        if (mode === 'reset' && (startIndex === -1 || endIndex === -1 || startIndex >= endIndex || displayedMessages.length === 0)) {
            lastRenderedDate = '';
            chatContainer.innerHTML = '<div class="text-center py-12 text-sm text-gray-400 dark:text-gray-500 italic">No messages found matching current filters.</div>';
            renderStart = 0;
            renderEnd = 0;
            return;
        }

        const snippet = displayedMessages.slice(startIndex, endIndex);

        if (snippet.length === 0) return;

        if (mode === 'reset') {
            lastRenderedDate = '';
            chatContainer.innerHTML = '';
            chatContainer.appendChild(generateChatsHtml(snippet));
            renderStart = startIndex;
            renderEnd = endIndex;
        } else if (mode === 'older') {
            lastRenderedDate = '';
            const frag = generateChatsHtml(snippet);
            const oldScroll = scrollArea.scrollHeight;
            chatContainer.insertBefore(frag, chatContainer.firstChild);
            scrollArea.scrollTop += (scrollArea.scrollHeight - oldScroll);
            renderStart = startIndex;
        } else if (mode === 'newer') {
            lastRenderedDate = displayedMessages[renderEnd - 1]?.date || '';
            const frag = generateChatsHtml(snippet);
            chatContainer.appendChild(frag);
            renderEnd = endIndex;
        }

        // Remove loaders visually as we approach the edges
        const topLoader = document.getElementById('top-loader');
        if (topLoader && renderStart === 0) topLoader.remove();
    };

    window.loadOlder = () => {
        if (renderStart <= 0) return;
        const newStart = Math.max(0, renderStart - CHUNK_SIZE);
        renderChats(newStart, renderStart, 'older');

        // Optional Memory Prune: Keep max 600 nodes
        if (renderEnd - renderStart > 600) {
            renderEnd -= CHUNK_SIZE;
            for (let i = 0; i < CHUNK_SIZE && chatContainer.lastElementChild; i++) {
                chatContainer.removeChild(chatContainer.lastElementChild);
            }
        }
    };

    window.loadNewer = () => {
        if (renderEnd >= displayedMessages.length) return;
        const newEnd = Math.min(displayedMessages.length, renderEnd + CHUNK_SIZE);
        const oldScroll = scrollArea.scrollTop;
        renderChats(renderEnd, newEnd, 'newer');

        // Prune from top
        if (renderEnd - renderStart > 600) {
            renderStart += CHUNK_SIZE;
            for (let i = 0; i < CHUNK_SIZE && chatContainer.firstElementChild; i++) {
                chatContainer.removeChild(chatContainer.firstElementChild);
            }
            scrollArea.scrollTop = oldScroll; // Maintain visual position
        }
    };

    let isScrolling = false;
    let scrollTimeout;
    let _scrollRaf = null;
    const floatingDate = document.getElementById('floating-date');

    // Cached date string for header — avoid repeated DOM updates
    let _lastHeaderDateStr = '';

    function parseMsgDate(dateStr) {
        if (!dateStr) return null;
        let day, mon, y;
        if (dateStr.includes('-')) {
            const parts = dateStr.split('-');
            if (parts.length !== 3) return null;
            y = parseInt(parts[0]);
            mon = parseInt(parts[1]);
            day = parseInt(parts[2]);
        } else if (dateStr.includes('/')) {
            const parts = dateStr.split('/');
            if (parts.length !== 3) return null;
            day = parseInt(parts[0]);
            mon = parseInt(parts[1]);
            y = parts[2].length === 2 ? 2000 + parseInt(parts[2]) : parseInt(parts[2]);
            
            // Fallback to MM/DD/YY if the parsed date is in the future
            const d = new Date(y, mon - 1, day);
            if (d > new Date()) {
                const altD = new Date(y, day - 1, mon);
                if (altD <= new Date()) {
                    const temp = day;
                    day = mon;
                    mon = temp;
                }
            }
        } else {
            return null;
        }
        return { day, mon, y };
    }

    scrollArea.addEventListener('scroll', () => {
        if (currentChat === '__global__') return;

        // Use rAF to batch scroll work — prevents layout thrashing
        if (!_scrollRaf) {
            _scrollRaf = requestAnimationFrame(() => {
                _scrollRaf = null;

                // ── Floating date + header date ── 
                // OPTIMIZED: Use array index instead of DOM querySelectorAll scan
                if (floatingDate && displayedMessages.length > 0) {
                    // Estimate visible message index from scroll position ratio
                    const scrollRatio = scrollArea.scrollTop / Math.max(1, scrollArea.scrollHeight - scrollArea.clientHeight);
                    const estimatedIdx = renderStart + Math.floor((renderEnd - renderStart) * scrollRatio);
                    const clampedIdx = Math.max(renderStart, Math.min(estimatedIdx, renderEnd - 1));

                    // Find date from displayedMessages array — O(1) vs O(n) DOM scan
                    const visibleMsg = displayedMessages[clampedIdx];
                    let closestDate = null;
                    if (visibleMsg && visibleMsg.date) {
                        const pd = parseMsgDate(visibleMsg.date);
                        if (pd) {
                            const dateObj = new Date(pd.y, pd.mon - 1, pd.day);
                            const monthName = dateObj.toLocaleString('en-IN', { month: 'long' });
                            closestDate = `${pd.day} ${monthName} ${pd.y}`;
                        }
                    }

                    if (closestDate) {
                        // Check if AI section is visible and override closestDate
                        const aiContainer = document.getElementById('ai-chat-container');
                        if (aiContainer && aiContainer.innerHTML.trim() !== '') {
                            const aiRect = aiContainer.getBoundingClientRect();
                            const scrollRect = scrollArea.getBoundingClientRect();
                            if (aiRect.top < scrollRect.bottom - 50) {
                                const aiSeps = Array.from(aiContainer.querySelectorAll('.ai-date-separator'));
                                if (aiSeps.length > 0) {
                                    let closestSep = aiSeps[aiSeps.length - 1];
                                    for (let i = 0; i < aiSeps.length; i++) {
                                        if (aiSeps[i].getBoundingClientRect().top > scrollRect.top + 50) {
                                            closestSep = i > 0 ? aiSeps[i - 1] : aiSeps[i];
                                            break;
                                        }
                                    }
                                    if (closestSep) {
                                        closestDate = closestSep.getAttribute('data-date') || closestDate;
                                    }
                                }
                            }
                        }

                        floatingDate.innerText = closestDate;
                        floatingDate.classList.remove('opacity-0');
                        floatingDate.classList.add('opacity-100');

                        if (dynamicHeaderDate && closestDate !== _lastHeaderDateStr) {
                            _lastHeaderDateStr = closestDate;
                            dynamicHeaderDate.innerText = closestDate;
                            dynamicHeaderDate.classList.remove('hidden');
                        }
                    }

                    clearTimeout(scrollTimeout);
                    scrollTimeout = setTimeout(() => {
                        floatingDate.classList.add('opacity-0', 'translate-y-[-10px]');
                        floatingDate.classList.remove('opacity-100', 'translate-y-0');
                    }, 1500);
                }

                // ── Infinite scroll: load older/newer chunks ──
                if (!isScrolling) {
                    if (scrollArea.scrollTop <= 400 && renderStart > 0) {
                        isScrolling = true;
                        window.loadOlder();
                        setTimeout(() => { isScrolling = false; }, 80);
                    }

                    if (Math.abs((scrollArea.scrollHeight - scrollArea.scrollTop) - scrollArea.clientHeight) <= 400 && renderEnd < displayedMessages.length) {
                        isScrolling = true;
                        window.loadNewer();
                        setTimeout(() => { isScrolling = false; }, 80);
                    }
                }
            });
        }
    }, { passive: true });

    const detectDateFormat = (messages) => {
        for (const msg of messages) {
            if (!msg.date) continue;
            const parts = msg.date.split('/');
            if (parts.length === 3) {
                const val0 = parseInt(parts[0], 10);
                const val1 = parseInt(parts[1], 10);
                if (val0 > 12) return { monthIdx: 1, dayIdx: 0 }; // DD/MM/YY
                if (val1 > 12) return { monthIdx: 0, dayIdx: 1 }; // MM/DD/YY
            }
        }
        return { monthIdx: 0, dayIdx: 1 }; // default MM/DD/YY
    };

    const animatePlaceholder = (inputEl, text) => {
        if (!inputEl) return;
        inputEl.targetPlaceholderText = text;

        if (inputEl.placeholderTimer) clearTimeout(inputEl.placeholderTimer);
        if (inputEl.cursorTimer) clearInterval(inputEl.cursorTimer);

        let index = 0;
        let currentText = '';
        const cursorChar = ' |';

        const type = () => {
            const currentTarget = inputEl.targetPlaceholderText || text;
            if (document.activeElement === inputEl) {
                inputEl.placeholder = currentTarget;
                return;
            }
            if (index < currentTarget.length) {
                currentText += currentTarget[index];
                inputEl.placeholder = currentText + cursorChar;
                index++;
                const delay = currentTarget[index - 1] === ' ' ? 80 : (35 + Math.random() * 40);
                inputEl.placeholderTimer = setTimeout(type, delay);
            } else {
                let showCursor = true;
                inputEl.placeholder = currentTarget + cursorChar;
                inputEl.cursorTimer = setInterval(() => {
                    if (document.activeElement === inputEl) {
                        inputEl.placeholder = currentTarget;
                        clearInterval(inputEl.cursorTimer);
                        return;
                    }
                    showCursor = !showCursor;
                    inputEl.placeholder = currentTarget + (showCursor ? cursorChar : '  ');
                }, 500);
            }
        };

        if (!inputEl.placeholderListenersAdded) {
            inputEl.placeholderListenersAdded = true;
            inputEl.addEventListener('focus', () => {
                if (inputEl.placeholderTimer) clearTimeout(inputEl.placeholderTimer);
                if (inputEl.cursorTimer) clearInterval(inputEl.cursorTimer);
                inputEl.placeholder = inputEl.targetPlaceholderText || text;
            });
            inputEl.addEventListener('blur', () => {
                if (!inputEl.value) {
                    animatePlaceholder(inputEl, inputEl.targetPlaceholderText || text);
                }
            });
        }

        type();
    };

    const loadData = async (chatName) => {
        // Mark messages for this chat as still loading so features (e.g. Wrapped)
        // don't show stale data from a previously opened chat (no mismatch).
        window.kothaChatLoading = true;
        window.kothaLoadedChat = null;
        try {
            // ── Client-side cache: re-opening a chat is instant (no network/re-fetch) ──
            if (!window._chatMsgCache) window._chatMsgCache = {};
            let data = window._chatMsgCache[chatName];

            if (!data) {
                showSkeleton();
                statsInfo.innerText = 'Loading...';
                const resp = await fetch(`/api/messages?chat=${encodeURIComponent(chatName)}`);
                data = await resp.json();

                if (data.error) {
                    statsInfo.innerText = "Error: " + data.error;
                    window.kothaChatLoading = false;
                    return;
                }
                // Stash in cache for instant re-open
                window._chatMsgCache[chatName] = data;
            }

            // Safety: if the user switched to a different chat while this was
            // loading, abort — never render one chat's data under another's name.
            if (currentChat !== chatName) { window.kothaChatLoading = false; return; }

            allMessages = data;
            // Messages now belong to this chat — safe for Wrapped to read.
            window.kothaLoadedChat = chatName;
            window.kothaChatLoading = false;
            displayedMessages = allMessages; // Default view is everything
            datePartsOrder = detectDateFormat(allMessages);

            // Cache last message preview for sidebar display
            if (!window._chatMetaCache) window._chatMetaCache = {};
            if (allMessages.length > 0) {
                // Backward loop instead of [...arr].reverse() — avoids copying huge arrays
                let lastTextMsg = null, count = 0;
                for (let i = allMessages.length - 1; i >= 0; i--) {
                    const m = allMessages[i];
                    if (m.type !== 'system') {
                        count++;
                        if (!lastTextMsg && m.text) lastTextMsg = m;
                    }
                }
                window._chatMetaCache[chatName] = {
                    ...window._chatMetaCache[chatName],
                    lastMessage: lastTextMsg ? (lastTextMsg.text.length > 40 ? lastTextMsg.text.slice(0, 40) + '…' : lastTextMsg.text) : '',
                    lastTime: lastTextMsg?.time || '',
                    count: count,
                };
            }

            // Clear previous dynamically added filters if changing chats
            const participantContainer = document.getElementById('participant-filters-container');
            if (participantContainer) {
                participantContainer.innerHTML = '';
                participantContainer.classList.add('hidden');
            }

            if (allMessages.length > 0) {
                const senderCounts = {};
                let totalMessages = 0;
                allMessages.forEach(msg => {
                    if (msg.sender && msg.type !== 'system') {
                        senderCounts[msg.sender] = (senderCounts[msg.sender] || 0) + 1;
                        totalMessages++;
                    }
                });

                const sortedSenders = Object.keys(senderCounts).sort((a, b) => senderCounts[b] - senderCounts[a]);
                const dynamicThreshold = Math.max(5, totalMessages * 0.01);
                const realParticipants = sortedSenders.filter(s => senderCounts[s] >= dynamicThreshold);
                if (realParticipants.length === 0) realParticipants.push(...sortedSenders);

                let isGroupChatFrontend = realParticipants.length > 2;
                if (isGroupChatFrontend && sortedSenders.length >= 2) {
                    const top2Messages = senderCounts[sortedSenders[0]] + senderCounts[sortedSenders[1]];
                    if (top2Messages / Math.max(totalMessages, 1) > 0.95) {
                        isGroupChatFrontend = false;
                        realParticipants.length = 2; // Trim to top 2
                        realParticipants[0] = sortedSenders[0];
                        realParticipants[1] = sortedSenders[1];
                    }
                }

                // Override senders array format to match existing code `[[name, count], ...]`
                const senders = realParticipants.map(s => [s, senderCounts[s]]);
                const senderNames = realParticipants;
                const chatContactName = chatName.replace('WhatsApp Chat - ', '');
                
                // Group Roles UI
                const groupRolesBtn = document.getElementById('group-roles-btn');
                if (groupRolesBtn) {
                    if (senderNames.length > 2) {
                        groupRolesBtn.classList.remove('hidden');
                        groupRolesBtn.onclick = () => window.openRolesModal(senderNames, chatName);
                    } else {
                        groupRolesBtn.classList.add('hidden');
                    }
                }

                // Check for user-defined roles for this group chat
                const customRoles = JSON.parse(localStorage.getItem('roles_' + chatName) || 'null');
                if (customRoles && customRoles.myName && customRoles.aiName) {
                    myName = customRoles.myName;
                    otherPersonName = customRoles.aiName;
                } else {
                    const resolved = resolveChatNames(chatContactName, senders);
                    otherPersonName = resolved.otherName;
                    myName = resolved.myName;
                }

                const isGroupChat = data.isGroup || isGroupChatFrontend;
                const actualGroupName = window._chatMetaCache?.[chatName]?.contactName || chatContactName;

                if (isGroupChat) {
                    headerName.innerText = actualGroupName.replace(/\(Group, \d+ members\)/, '').trim();
                    const participantCount = data.participants ? data.participants.length : senderNames.length;
                    const subTitle = document.createElement('span');
                    subTitle.className = 'text-[11px] font-normal text-gray-400 block -mt-1';
                    subTitle.innerText = `${participantCount} members`;
                    headerName.appendChild(subTitle);
                    
                    headerAvatar.innerHTML = `<svg class="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>`;
                    if (sidebarAvatar) sidebarAvatar.innerText = 'G';
                } else {
                    headerName.innerText = otherPersonName;
                    if (otherPersonName) {
                        headerAvatar.innerText = otherPersonName.charAt(0).toUpperCase();
                        if (sidebarAvatar) sidebarAvatar.innerText = 'C';
                    }
                }
                
                sidebarTitle.innerText = "All Chats";

                if (window._chatMetaCache[chatName]) {
                    window._chatMetaCache[chatName].contactName = isGroupChat ? actualGroupName : otherPersonName;
                }
                renderChatList(loadedChats, currentChat);

                // Animate bottom input placeholder typewriter effect
                const bottomAiInput = document.getElementById('bottom-ai-input');
                if (bottomAiInput) {
                    animatePlaceholder(bottomAiInput, isGroupChat ? `Continue With virtual Group Chat…` : `Continue With virtual ${otherPersonName}…`);
                }

                statsInfo.innerHTML = `Loaded <span class="font-bold text-blue-600 dark:text-blue-400">${allMessages.length.toLocaleString()}</span> messages dynamically.`;

                // Add Sender Filters to the Participant Container automatically (toggle on/off)
                let activeSenderFilter = null;
                const senderBtns = [];
                
                if (senders.length > 0 && participantContainer) {
                    participantContainer.classList.remove('hidden');
                    
                    const label = document.createElement('div');
                    label.className = 'w-full text-[9px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-0.5 mt-1';
                    label.innerText = 'Participants';
                    participantContainer.appendChild(label);

                    senders.slice(0, 4).forEach(([sName, count]) => {
                        if (!sName) return;
                        const btn = document.createElement('button');
                        const defaultClass = 'text-[10px] bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full px-2 py-0.5 font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition whitespace-nowrap cursor-pointer flex items-center gap-1.5 font-sans';
                        const activeClass = 'text-[10px] bg-indigo-600 border border-indigo-600 rounded-full px-2 py-0.5 font-medium text-white hover:bg-indigo-700 transition whitespace-nowrap cursor-pointer flex items-center gap-1.5 font-sans';
                        
                        btn.className = defaultClass;
                        btn.innerHTML = `<div class="w-3.5 h-3.5 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 text-white flex items-center justify-center text-[7.5px] font-bold tracking-tighter">${sName.charAt(0).toUpperCase()}</div> <span>${sName}</span>`;
                        
                        btn.onclick = () => {
                            if (activeSenderFilter === sName) {
                                // Toggle OFF
                                activeSenderFilter = null;
                                displayedMessages = [...allMessages];
                                senderBtns.forEach(b => {
                                    b.className = defaultClass;
                                    b.querySelector('div').className = 'w-3.5 h-3.5 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 text-white flex items-center justify-center text-[7.5px] font-bold tracking-tighter';
                                });
                                statsInfo.innerHTML = `Showing all <span class="font-bold text-blue-600 dark:text-blue-400">${allMessages.length.toLocaleString()}</span> messages.`;
                            } else {
                                // Toggle ON
                                activeSenderFilter = sName;
                                displayedMessages = allMessages.filter(msg => msg.sender === sName);
                                senderBtns.forEach(b => {
                                    b.className = defaultClass + ' opacity-50';
                                    b.querySelector('div').className = 'w-3.5 h-3.5 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 text-white flex items-center justify-center text-[7.5px] font-bold tracking-tighter';
                                });
                                btn.className = activeClass;
                                btn.querySelector('div').className = 'w-3.5 h-3.5 rounded-full bg-white text-indigo-600 flex items-center justify-center text-[7.5px] font-bold tracking-tighter';
                                statsInfo.innerHTML = `Showing <span class="font-bold text-indigo-600 dark:text-indigo-400">${displayedMessages.length.toLocaleString()}</span> msgs by ${sName}.`;
                            }
                            renderChats(-1, -1);
                            renderChats(0, Math.min(CHUNK_SIZE, displayedMessages.length), 'reset');
                            setTimeout(() => scrollArea.scrollTop = 0, 10);
                            toggleSidebar(false);
                        };
                        senderBtns.push(btn);
                        participantContainer.appendChild(btn);
                    });
                }

                // Populate Smart Filters (Years & Days)
                const years = new Set();
                allMessages.forEach(msg => {
                    if (!msg.date) return;
                    const parts = msg.date.split('/');
                    if (parts.length === 3) years.add(parts[2]);
                });
                const yearSelect = document.getElementById('filter-year');
                yearSelect.innerHTML = '<option value="">Year</option>';
                [...years].sort().forEach(y => {
                    const fullYear = y.length === 2 ? `20${y}` : y;
                    yearSelect.innerHTML += `<option value="${y}">${fullYear}</option>`;
                });
                const daySelect = document.getElementById('filter-day');
                daySelect.innerHTML = '<option value="">Day</option>';
                for (let i = 1; i <= 31; i++) {
                    daySelect.innerHTML += `<option value="${i}">${i}</option>`;
                }

                // Smart Filters Logic — Apply button driven (no auto-change listeners)
                const filterMonth = document.getElementById('filter-month');
                const toggleMedia = document.getElementById('toggle-media');
                const toggleStickers = document.getElementById('toggle-stickers');
                const toggleLinks = document.getElementById('toggle-links');
                const resetFiltersBtn = document.getElementById('reset-filters');
                const applyFiltersBtn = document.getElementById('apply-filters-btn');

                const applyFilters = () => {
                    const d = daySelect.value;
                    const m = filterMonth.value;
                    const y = yearSelect.value;
                    const showMedia = toggleMedia.checked;
                    const showStickers = toggleStickers.checked;
                    const showLinks = toggleLinks ? toggleLinks.checked : false;
                    const hasDateFilter = !!(d || m || y);

                    if (hasDateFilter || !showMedia || !showStickers || showLinks) {
                        resetFiltersBtn.classList.remove('hidden');
                    } else {
                        resetFiltersBtn.classList.add('hidden');
                    }

                    displayedMessages = allMessages.filter(msg => {
                        // Respect active sender filter
                        if (activeSenderFilter && msg.sender !== activeSenderFilter) return false;

                        // Content check
                        if (!showMedia && msg.attachment) return false;

                        if (msg.text) {
                            const text = msg.text.toLowerCase();

                            if (showLinks) {
                                if (!text.includes('http') && !text.includes('www.')) return false;
                            }

                            if (!showMedia) {
                                const mediaExts = ['.jpg', '.jpeg', '.png', '.mp4', '.mov', 'image omitted', 'video omitted', 'audio omitted', 'document omitted'];
                                if (mediaExts.some(ext => text.includes(ext))) return false;
                            }

                            if (!showStickers) {
                                const stickerExts = ['.webp', 'sticker omitted'];
                                if (stickerExts.some(ext => text.includes(ext))) return false;
                            }
                        } else {
                            if (showLinks) return false;
                        }

                        return true;
                    });

                    // Find index of the first message matching the date filter
                    let targetIdx = -1;
                    if (hasDateFilter) {
                        targetIdx = displayedMessages.findIndex(msg => {
                            if (!msg.date) return false;
                            const parts = msg.date.split('/');
                            if (parts.length === 3) {
                                const msgM = parseInt(parts[datePartsOrder.monthIdx]);
                                const msgD = parseInt(parts[datePartsOrder.dayIdx]);
                                const msgY = parts[2];

                                if (m && msgM !== parseInt(m)) return false;
                                if (d && msgD !== parseInt(d)) return false;
                                if (y && msgY !== y) return false;
                                return true;
                            }
                            return false;
                        });
                    }

                    renderChats(-1, -1); // Clear UI

                    if (displayedMessages.length > 0) {
                        if (hasDateFilter && targetIdx !== -1) {
                            // Date matches, render chunk centered around it
                            const start = Math.max(0, targetIdx - 30);
                            const end = Math.min(displayedMessages.length, start + CHUNK_SIZE);
                            renderChats(start, end, 'reset');
                            setTimeout(() => {
                                const targetMsg = displayedMessages[targetIdx];
                                const targetEl = document.getElementById(`msg-${targetMsg.id}`);
                                if (targetEl) {
                                    targetEl.scrollIntoView({ block: 'center', behavior: 'smooth' });
                                    targetEl.classList.add('jump-highlight');
                                    setTimeout(() => {
                                        targetEl.classList.remove('jump-highlight');
                                    }, 2500);
                                }
                            }, 80);
                            statsInfo.innerHTML = `Jumped to date. Showing <span class="font-bold text-indigo-600 dark:text-indigo-400">${displayedMessages.length.toLocaleString()}</span> total messages.`;
                        } else {
                            // Default: show newest messages at bottom
                            const end = displayedMessages.length;
                            renderChats(Math.max(0, end - CHUNK_SIZE), end, 'reset');
                            setTimeout(() => { scrollArea.scrollTop = scrollArea.scrollHeight; }, 10);

                            if (hasDateFilter && targetIdx === -1) {
                                statsInfo.innerHTML = `<span class="text-red-500 font-semibold">No messages found on that date.</span> Showing all ${displayedMessages.length.toLocaleString()} messages.`;
                            } else {
                                statsInfo.innerHTML = `Showing <span class="font-bold text-indigo-600 dark:text-indigo-400">${displayedMessages.length.toLocaleString()}</span> messages.`;
                            }
                        }
                    } else {
                        statsInfo.innerHTML = `Showing <span class="font-bold text-indigo-600 dark:text-indigo-400">0</span> messages.`;
                    }

                    // Close sidebar on mobile after applying
                    toggleSidebar(false);
                };

                // Apply button — single click to filter
                if (applyFiltersBtn) {
                    applyFiltersBtn.addEventListener('click', applyFilters);
                }

                // NO auto-change listeners on dropdowns — only the Apply button triggers filtering
                // Checkboxes still auto-apply since they're simple toggles
                [toggleMedia, toggleStickers, toggleLinks].forEach(el => {
                    if (el) el.addEventListener('change', applyFilters);
                });

                resetFiltersBtn.addEventListener('click', () => {
                    daySelect.value = ''; filterMonth.value = ''; yearSelect.value = '';
                    toggleMedia.checked = true; toggleStickers.checked = true;
                    if (toggleLinks) toggleLinks.checked = false;
                    applyFilters();
                });

                // Initial render: last CHUNK_SIZE messages
                const end = allMessages.length;
                const start = Math.max(0, end - CHUNK_SIZE);
                renderChats(start, end);

                setTimeout(() => {
                    scrollArea.scrollTop = scrollArea.scrollHeight;
                }, 100);

                if (window.kothaLoadAiHistory) {
                    window.kothaLoadAiHistory(chatName);
                }

            } else {
                chatContainer.innerHTML = '';
            }
        } catch (e) {
            statsInfo.innerText = "Fetch error: " + e.message;
            window.kothaChatLoading = false;
        }
    };

    // ---------- Chat List UI Rendering ----------
    const chatListUI = document.getElementById('chat-list-ui');

    const chatColors = [
        'from-emerald-400 to-teal-500',
        'from-violet-500 to-indigo-600',
        'from-pink-500 to-rose-500',
        'from-amber-400 to-orange-500',
        'from-cyan-400 to-blue-500',
        'from-fuchsia-500 to-purple-600',
    ];

    function renderChatList(chats, activeChat) {
        if (!chatListUI) return;
        chatListUI.innerHTML = '';
        if (chats.length === 0) {
            chatListUI.innerHTML = '<p class="text-xs text-gray-400 text-center py-4">No chats yet. Import one!</p>';
            return;
        }
        chats.forEach((chat, idx) => {
            const chatMeta = window._chatMetaCache?.[chat];
            let displayName = chatMeta?.contactName ? cleanDisplayName(chatMeta.contactName) : cleanDisplayName(chat);
            const initial = displayName.charAt(0).toUpperCase();
            const colorClass = chatColors[idx % chatColors.length];
            const isActive = chat === activeChat;

            // Get last message preview from cache if available
            const lastMsg = chatMeta?.lastMessage || '';
            const lastTime = chatMeta?.lastTime || '';
            const msgCount = chatMeta?.messageCount || chatMeta?.count || '';

            const item = document.createElement('div');
            item.className = `flex items-center gap-2 px-2 py-1 rounded-lg cursor-pointer transition-all duration-150 group ${isActive ? 'bg-[#f0f2f5] dark:bg-[#2a3942]' : 'hover:bg-[#f5f6f6] dark:hover:bg-[#202c33]'}`;
            item.dataset.chat = chat;
            item.innerHTML = `
                <div class="w-8 h-8 rounded-full bg-gradient-to-br ${colorClass} flex items-center justify-center text-white font-bold text-sm shadow-sm shrink-0">${initial}</div>
                <div class="min-w-0 flex-1 border-b border-gray-100 dark:border-gray-800/50 pb-1">
                    <div class="flex items-center justify-between gap-1 mt-0.5">
                        <div class="flex items-center gap-1 overflow-hidden">
                            <p class="text-[14px] font-normal text-gray-900 dark:text-gray-100 truncate leading-tight">${escapeHTML(displayName)}</p>
                            ${chatMeta?.deletedByUser ? '<span class="px-1 py-0.5 rounded text-[9px] font-bold bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400 border border-red-200 dark:border-red-800 shrink-0">Deleted</span>' : ''}
                        </div>
                        <span class="text-[10px] text-gray-400 font-medium shrink-0 whitespace-nowrap">${lastTime}</span>
                    </div>
                    <div class="flex items-center justify-between gap-1 mt-0.5">
                        <p class="text-[11px] text-gray-400 font-medium truncate leading-tight">${lastMsg ? escapeHTML(lastMsg) : (isActive ? '● Active' : 'Tap to open')}</p>
                        ${msgCount ? `<span class="bg-indigo-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full shadow-sm shrink-0">${msgCount > 9999 ? (msgCount/1000).toFixed(1) + 'k' : (msgCount > 999 ? '999+' : msgCount)}</span>` : ''}
                    </div>
                </div>
                <div class="flex items-center gap-0.5 shrink-0 opacity-0 group-hover:opacity-100 transition">
                    <button class="chat-rename-btn w-7 h-7 rounded-lg flex items-center justify-center text-gray-300 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 transition" title="Rename chat" data-chat="${chat}">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                    </button>
                    <button class="chat-del-btn w-7 h-7 rounded-lg flex items-center justify-center text-gray-300 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition" title="Delete chat" data-chat="${chat}">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                    </button>
                </div>
            `;
            // Rename button
            item.querySelector('.chat-rename-btn').addEventListener('click', async (e) => {
                e.stopPropagation();
                const newName = prompt(`Rename "${displayName}" to:`, displayName);
                if (!newName || !newName.trim() || newName.trim() === displayName) return;
                const cleanNewName = newName.trim();
                try {
                    const r = await fetch(`/api/chats/${encodeURIComponent(chat)}/rename`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ newName: cleanNewName })
                    });
                    if (!r.ok) throw new Error('Rename failed');
                    if (!window._chatMetaCache) window._chatMetaCache = {};
                    if (!window._chatMetaCache[chat]) window._chatMetaCache[chat] = {};
                    window._chatMetaCache[chat].contactName = cleanNewName;
                    
                    if (chat === currentChat) {
                        const headerName = document.getElementById('contact-name');
                        if (headerName) headerName.innerText = cleanNewName;
                    }
                    renderChatList(loadedChats, currentChat);
                } catch (err) {
                    alert('Rename failed: ' + err.message);
                }
            });

            // Delete button
            item.querySelector('.chat-del-btn').addEventListener('click', async (e) => {
                e.stopPropagation();
                if (!confirm(`Delete "${displayName}"?\n\nYou won't see this chat anymore.`)) return;
                try {
                    const r = await fetch(`/api/chats/${encodeURIComponent(chat)}`, { method: 'DELETE' });
                    if (!r.ok) throw new Error('Failed');
                    loadedChats = loadedChats.filter(c => c !== chat);
                    if (chat === currentChat && loadedChats.length > 0) {
                        currentChat = loadedChats[0];
                        window.currentChat = loadedChats[0];
                        loadData(loadedChats[0]);
                    } else if (loadedChats.length === 0) {
                        currentChat = '';
                        window.currentChat = '';
                        showEmptyState();
                    }
                    renderChatList(loadedChats, currentChat);
                } catch (err) {
                    alert('Delete failed: ' + err.message);
                }
            });
            // Open chat on click
            item.addEventListener('click', (e) => {
                if (e.target.closest('.chat-del-btn')) return;
                if (chat === currentChat) {
                    if (window.innerWidth < 768 || window.kothaCompact) toggleSidebar(false);
                    return;
                }
                if (currentChat === '__global__') {
                    deactivateGlobalUI();
                }
                currentChat = chat;
                window.currentChat = chat;
                const selector = document.getElementById('chat-selector');
                if (selector) selector.value = chat;
                renderChatList(chats, chat);
                loadData(chat).then(() => {
                    const inp = document.getElementById('bottom-ai-input');
                    if (inp) inp.focus();
                });
                toggleSidebar(false);
                // Also try focus after sidebar animation completes (mobile)
                setTimeout(() => { const inp = document.getElementById('bottom-ai-input'); if (inp) inp.focus(); }, 350);
            });
            chatListUI.appendChild(item);
        });
    }

    // Keep reference to loaded chats for re-rendering
    let loadedChats = [];

    const loadChatsList = async () => {
        // Show skeleton in sidebar while loading
        if (chatListUI) {
            chatListUI.innerHTML = `
                <div class="skeleton-chat-item"><div class="skeleton skeleton-avatar"></div><div class="skeleton-lines"><div class="skeleton skeleton-line skeleton-line-long"></div><div class="skeleton skeleton-line skeleton-line-short"></div></div></div>
                <div class="skeleton-chat-item"><div class="skeleton skeleton-avatar"></div><div class="skeleton-lines"><div class="skeleton skeleton-line skeleton-line-long"></div><div class="skeleton skeleton-line skeleton-line-short"></div></div></div>
                <div class="skeleton-chat-item"><div class="skeleton skeleton-avatar"></div><div class="skeleton-lines"><div class="skeleton skeleton-line skeleton-line-long"></div><div class="skeleton skeleton-line skeleton-line-short"></div></div></div>
            `;
        }
        try {
            const resp = await fetch('/api/chats');
            if (resp.status === 401) {
                // not logged in
                return;
            }
            const chats = await resp.json();
            loadedChats = chats;
            
            fetch('/api/chats/meta').then(r => r.json()).then(metaMap => {
                if (!window._chatMetaCache) window._chatMetaCache = {};
                for (const [folder, meta] of Object.entries(metaMap)) {
                    if (!window._chatMetaCache[folder]) window._chatMetaCache[folder] = {};
                    if (typeof meta === 'object' && meta !== null) {
                        window._chatMetaCache[folder].contactName = meta.display_name;
                        window._chatMetaCache[folder].deletedByUser = meta.deleted_by_user;
                        window._chatMetaCache[folder].messageCount = meta.message_count;
                        window._chatMetaCache[folder].isGroup = meta.is_group === 1;
                        window._chatMetaCache[folder].participants = meta.participants;
                    } else {
                        window._chatMetaCache[folder].contactName = meta; // backwards compatibility
                    }
                }
                renderChatList(loadedChats, currentChat);
            }).catch(() => {});
            const selector = document.getElementById('chat-selector');
            if (!selector) return;
            selector.innerHTML = '<option value="">Select a chat...</option>';
            chats.forEach(chat => {
                const opt = document.createElement('option');
                opt.value = chat;
                opt.textContent = chat.replace('WhatsApp Chat - ', '');
                selector.appendChild(opt);
            });
            if (chats.length > 0) {
                if (currentChat === '__global__') {
                    removeEmptyState();
                    renderChatList(chats, '');
                } else {
                    const urlParams = new URLSearchParams(window.location.search);
                    const targetChat = urlParams.get('chat');
                    let startChat = chats[0];
                    if (targetChat) {
                        const match = chats.find(c => c === targetChat || c.toLowerCase() === targetChat.toLowerCase());
                        if (match) startChat = match;
                    }

                    selector.value = startChat;
                    currentChat = startChat;
                    window.currentChat = startChat;
                    loadData(startChat);
                    removeEmptyState();
                    // Render visual chat list
                    renderChatList(chats, startChat);
                }
            } else {
                if (currentChat !== '__global__') {
                    showEmptyState();
                }
                renderChatList([], '');
            }
        } catch (e) {
            console.error("Failed to load chats:", e);
            statsInfo.innerText = "Error loading chats list";
        }
    };

    // ── Skeleton Loading ──
    function showSkeleton() {
        chatContainer.innerHTML = `
            <div id="chat-skeleton" class="py-4 px-2">
                <div class="skeleton skeleton-date"></div>
                <div class="skeleton skeleton-bubble-left" style="width:50%;animation-delay:0.1s"></div>
                <div class="skeleton skeleton-bubble-right" style="animation-delay:0.2s"></div>
                <div class="skeleton skeleton-bubble-left" style="width:60%;animation-delay:0.3s"></div>
                <div class="skeleton skeleton-bubble-right-sm" style="animation-delay:0.4s"></div>
                <div class="skeleton skeleton-date" style="animation-delay:0.5s"></div>
                <div class="skeleton skeleton-bubble-right" style="width:55%;animation-delay:0.6s"></div>
                <div class="skeleton skeleton-bubble-left" style="animation-delay:0.7s"></div>
                <div class="skeleton skeleton-bubble-right-sm" style="width:35%;animation-delay:0.8s"></div>
                <div class="skeleton skeleton-bubble-left" style="width:45%;animation-delay:0.9s"></div>
            </div>`;
    }

    function showEmptyState() {
        const container = document.getElementById('chat-container');
        if (!container) return;
        container.innerHTML = `
            <div class="w-full my-auto flex flex-col items-center pt-[3vh] min-[800px]:pt-[8vh] pb-8 px-6 text-center" id="empty-state">
                <div class="empty-state-float mb-3 sm:mb-6 relative shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" class="w-12 h-12 sm:w-16 sm:h-16 drop-shadow-2xl">
                      <defs>
                        <linearGradient id="g1" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stop-color="#4F46E5"/>
                          <stop offset="100%" stop-color="#9333EA"/>
                        </linearGradient>
                        <linearGradient id="g2" x1="100%" y1="0%" x2="0%" y2="100%">
                          <stop offset="0%" stop-color="#EC4899"/>
                          <stop offset="100%" stop-color="#8B5CF6"/>
                        </linearGradient>
                        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                          <feDropShadow dx="0" dy="0" stdDeviation="3" flood-color="#8b5cf6" flood-opacity="0.55"/>
                        </filter>
                        <filter id="orb" x="-80%" y="-80%" width="260%" height="260%">
                          <feDropShadow dx="0" dy="0" stdDeviation="2" flood-color="#ffffff" flood-opacity="0.9"/>
                        </filter>
                      </defs>
                      <path d="M35 30 C 15 30 15 70 35 70 C 50 70 50 30 65 30 C 85 30 85 70 65 70 C 50 70 50 30 35 30 Z" fill="none" stroke="url(#g1)" stroke-width="13" stroke-linecap="round" stroke-linejoin="round" filter="url(#glow)"/>
                      <path d="M35 30 C 50 30 50 70 65 70" fill="none" stroke="url(#g2)" stroke-width="13" stroke-linecap="round" stroke-linejoin="round" opacity="0.95"/>
                      <circle r="5" filter="url(#orb)"><animate attributeName="fill" values="#ffffff;#ec4899;#8b5cf6;#4f46e5;#ffffff" dur="4s" repeatCount="indefinite"/><animateMotion dur="4s" repeatCount="indefinite" path="M35 30 C 15 30 15 70 35 70 C 50 70 50 30 65 30 C 85 30 85 70 65 70 C 50 70 50 30 35 30 Z" calcMode="linear"/></circle>
                    </svg>
                </div>
                <h2 class="text-xl sm:text-2xl md:text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white mb-2">Bring your chats to life</h2>
                <p class="text-[13px] sm:text-[14px] md:text-[15px] text-gray-500 dark:text-gray-400 max-w-sm leading-relaxed mb-4 sm:mb-6">Import your chat history to search, analyze, and relive memories with an AI-generated simulation.</p>
                
                <div class="flex items-center justify-center gap-2 sm:gap-4 md:gap-6 text-[10px] sm:text-[11px] md:text-[12px] text-gray-400 dark:text-gray-500 font-medium mb-5 sm:mb-8 bg-gray-50 dark:bg-gray-800/50 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full border border-gray-100 dark:border-gray-800 scale-90 sm:scale-100">
                    <span class="flex items-center gap-1 sm:gap-1.5"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="sm:w-[14px] sm:h-[14px]"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg> Private</span>
                    <span class="w-1 h-1 rounded-full bg-gray-300 dark:bg-gray-600"></span>
                    <span class="flex items-center gap-1 sm:gap-1.5"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="sm:w-[14px] sm:h-[14px]"><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/></svg> AI-powered</span>
                    <span class="w-1 h-1 rounded-full bg-gray-300 dark:bg-gray-600"></span>
                    <span class="flex items-center gap-1 sm:gap-1.5"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="sm:w-[14px] sm:h-[14px]"><path d="M5 12h14M12 5l7 7-7 7"/></svg> Fast</span>
                </div>

                <div class="flex flex-wrap items-center justify-center gap-2 sm:gap-3 w-full max-w-sm mx-auto">
                    <button id="empty-upload-btn" class="flex-1 min-w-[140px] sm:min-w-[160px] whitespace-nowrap bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-[13px] sm:text-[14px] rounded-xl px-4 sm:px-6 py-2.5 sm:py-3 transition-all shadow-md flex items-center justify-center gap-2 sm:gap-2.5">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
                        Import Chat
                    </button>
                    <button id="empty-dm-btn" class="flex-1 min-w-[140px] sm:min-w-[160px] whitespace-nowrap bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400 font-semibold text-[13px] sm:text-[14px] rounded-xl px-4 sm:px-6 py-2.5 sm:py-3 transition-all hover:bg-indigo-50 dark:hover:bg-indigo-900/20 flex items-center justify-center gap-2 sm:gap-2.5 shadow-sm">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                        Message Someone
                    </button>
                </div>
            </div>
        `;
        const btn = document.getElementById('empty-upload-btn');
        if (btn) btn.addEventListener('click', () => {
            const openUploadBtn = document.getElementById('open-upload-btn');
            if (openUploadBtn) openUploadBtn.click();
        });
        const dmBtn = document.getElementById('empty-dm-btn');
        if (dmBtn) dmBtn.addEventListener('click', () => {
            // Open DM sidebar via the btn-dm button
            const btnDm = document.getElementById('btn-dm');
            if (btnDm) btnDm.click();
        });
    }
    function removeEmptyState() {
        const e = document.getElementById('empty-state');
        if (e) e.remove();
    }

    const chatSelector = document.getElementById('chat-selector');
    if (chatSelector) {
        chatSelector.addEventListener('change', (e) => {
            if (e.target.value) {
                if (currentChat === '__global__') {
                    deactivateGlobalUI();
                }
                currentChat = e.target.value;
                window.currentChat = currentChat;
                loadData(currentChat);
            }
        });
    }

    // Expose for upload.js to refresh after import
    window.refreshChats = async (selectName) => {
        await loadChatsList();
        if (selectName) {
            if (currentChat === '__global__') {
                deactivateGlobalUI();
            }
            const selector = document.getElementById('chat-selector');
            if (selector) {
                selector.value = selectName;
                currentChat = selectName;
                window.currentChat = selectName;
                loadData(selectName);
                // Re-render chat list with new active
                renderChatList(loadedChats, selectName);
            }
        }
    };

    // Inline Filters toggle under search bar
    const filtersToggle = document.getElementById('btn-filters-toggle');
    const filtersContainer = document.getElementById('smart-filters-container');
    const closeFiltersBtn = document.getElementById('close-filters-btn');
    if (filtersToggle && filtersContainer) {
        function openFilters() {
            filtersContainer.classList.remove('hidden');
            filtersToggle.classList.add('text-amber-600', 'bg-amber-50', 'dark:bg-amber-900/30');
            // Scroll sidebar list to top so filters are in full view
            const sidebarChatsTab = document.getElementById('sidebar-chats-tab');
            if (sidebarChatsTab) sidebarChatsTab.scrollTop = 0;
        }
        function closeFilters() {
            filtersContainer.classList.add('hidden');
            filtersToggle.classList.remove('text-amber-600', 'bg-amber-50', 'dark:bg-amber-900/30');
        }
        filtersToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            if (filtersContainer.classList.contains('hidden')) { openFilters(); } else { closeFilters(); }
        });
        if (closeFiltersBtn) closeFiltersBtn.addEventListener('click', closeFilters);
    }


    // Expose for ai-panel.js — keep window.currentChat in sync
    window.scrollToMessageId = (id) => {
        if (typeof window.jumpToMsg === 'function') {
            window.jumpToMsg(id);
        }
    };

    // ── Onboarding Flow (first-time users) ──
    function showOnboarding() {
        if (localStorage.getItem('kotha_onboarded')) return;
        const steps = [
            {
                icon: '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="1.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>',
                title: 'Upload your chat',
                desc: 'Export your chat history as a .zip file and drop it here. We support Android, iPhone, individual and group chats.',
            },
            {
                icon: '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="1.5"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>',
                title: 'See your chats beautifully',
                desc: 'Messages appear in beautiful chat bubbles with photos, videos, and voice notes inline. Search through years instantly.',
            },
            {
                icon: '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="1.5"><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/></svg>',
                title: 'Talk with AI',
                desc: 'AI learns how your contact texts — their slang, emojis, humor — and responds just like them. Click the sparkle button to start!',
            },
        ];
        let step = 0;

        function renderStep() {
            const s = steps[step];
            const dots = steps.map((_, i) => `<div class="onboarding-step-dot ${i === step ? 'active' : ''}"></div>`).join('');
            const isLast = step === steps.length - 1;
            document.getElementById('onboarding-overlay').innerHTML = `
                <div class="onboarding-card">
                    <div class="w-16 h-16 rounded-2xl bg-indigo-50 flex items-center justify-center mx-auto mb-5">${s.icon}</div>
                    <h3 class="text-xl font-bold text-gray-900 mb-2">${s.title}</h3>
                    <p class="text-sm text-gray-500 leading-relaxed mb-6 max-w-xs mx-auto">${s.desc}</p>
                    <div class="flex items-center justify-center gap-2 mb-5">${dots}</div>
                    <div class="flex gap-3 justify-center">
                        <button id="onboard-skip" class="text-sm text-gray-400 hover:text-gray-600 font-medium px-4 py-2 transition">${isLast ? '' : 'Skip'}</button>
                        <button id="onboard-next" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-xl px-6 py-2.5 transition shadow-sm">${isLast ? 'Get Started!' : 'Next'}</button>
                    </div>
                </div>
            `;
            document.getElementById('onboard-next').addEventListener('click', () => {
                if (isLast) { closeOnboarding(); return; }
                step++;
                renderStep();
            });
            const skipBtn = document.getElementById('onboard-skip');
            if (skipBtn) skipBtn.addEventListener('click', closeOnboarding);
        }

        function closeOnboarding() {
            localStorage.setItem('kotha_onboarded', '1');
            const overlay = document.getElementById('onboarding-overlay');
            if (overlay) { overlay.style.opacity = '0'; setTimeout(() => overlay.remove(), 300); }
        }

        const overlay = document.createElement('div');
        overlay.id = 'onboarding-overlay';
        overlay.className = 'onboarding-overlay';
        document.body.appendChild(overlay);
        renderStep();
    }

    // ── Global Chat Room Logic ──
    let globalEventSource = null;
    const globalChatItem = document.getElementById('global-chat-item');
    const globalOnlineUsersList = document.getElementById('global-online-users-list');
    const globalActiveIndicator = document.getElementById('global-active-indicator');
    const globalOnlineCount = document.getElementById('global-online-count');
    const askAiBtn = document.getElementById('ask-ai-btn');
    const bottomAiInput = document.getElementById('bottom-ai-input');
    const clearGlobalChatBtn = document.getElementById('clear-global-chat-btn');

    // Poll online count independently of SSE so the sidebar updates globally
    async function pollGlobalOnlineCount() {
        if (currentChat === '__global__') return; // SSE handles it when inside
        try {
            const r = await fetch('/api/global-chat/online-count');
            const data = await r.json();
            if (globalOnlineCount) {
                globalOnlineCount.textContent = `${data.count} user${data.count === 1 ? '' : 's'} online`;
            }
        } catch (err) {}
    }
    setInterval(pollGlobalOnlineCount, 5000);
    pollGlobalOnlineCount();

    // Reply and Reaction State variables
    window.replyingTo = null;
    let activePicker = null;

    const replyPreview = document.getElementById('reply-preview-container');
    const replySender = document.getElementById('reply-preview-sender');
    const replyText = document.getElementById('reply-preview-text');
    const replyClose = document.getElementById('reply-preview-close');
    const inputWrap = document.getElementById('ai-input-wrap');

    function setupReply(msgId, sender, text) {
        window.replyingTo = { msgId, sender, text };
        if (replySender) replySender.textContent = sender;
        if (replyText) replyText.textContent = text;
        if (replyPreview) replyPreview.classList.remove('hidden');
        if (inputWrap) {
            inputWrap.classList.remove('rounded-2xl');
            inputWrap.classList.add('rounded-b-2xl', 'rounded-t-none', 'border-t', 'border-gray-100', 'dark:border-gray-800');
        }
        if (bottomAiInput) bottomAiInput.focus();
    }

    window.clearReplyPreview = function () {
        window.replyingTo = null;
        if (replyPreview) replyPreview.classList.add('hidden');
        if (inputWrap) {
            inputWrap.classList.add('rounded-2xl');
            inputWrap.classList.remove('rounded-b-2xl', 'rounded-t-none', 'border-t', 'border-gray-100', 'dark:border-gray-800');
        }
    };

    if (replyClose) {
        replyClose.addEventListener('click', window.clearReplyPreview);
    }

    function showReactionPicker(btn, msgId) {
        if (activePicker) activePicker.remove();

        const picker = document.createElement('div');
        picker.className = 'reaction-picker absolute bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-full px-2.5 py-1.5 flex items-center gap-1 z-50 shadow-lg';

        const emojis = ['👍', '❤️', '😂', '😮', '😢', '🙏'];
        emojis.forEach(emoji => {
            const emojiBtn = document.createElement('button');
            emojiBtn.className = 'reaction-emoji-btn text-[17px] hover:scale-125 transition duration-150 p-1 cursor-pointer';
            emojiBtn.textContent = emoji;
            emojiBtn.addEventListener('click', () => {
                sendReaction(msgId, emoji);
                picker.remove();
            });
            picker.appendChild(emojiBtn);
        });

        document.body.appendChild(picker);
        const rect = btn.getBoundingClientRect();
        picker.style.position = 'fixed';
        picker.style.left = `${rect.left + window.scrollX - 70}px`;
        picker.style.top = `${rect.top + window.scrollY - 46}px`;

        activePicker = picker;

        setTimeout(() => {
            document.addEventListener('click', (e) => {
                if (picker.parentNode && !picker.contains(e.target) && e.target !== btn) {
                    picker.remove();
                }
            }, { once: true });
        }, 10);
    }

    async function sendReaction(messageId, emoji) {
        try {
            await fetch('/api/global-chat/react', {
                method: 'POST',
                headers: { 'content-type': 'application/json' },
                body: JSON.stringify({ messageId, emoji })
            });
        } catch (err) {
            console.error('Failed to send reaction:', err);
        }
    }

    function updateMessageReactionsInDOM(messageId, reactions) {
        const msgEl = document.getElementById(`global-msg-${messageId}`);
        if (!msgEl) return;

        const bubbleEl = msgEl.querySelector('.glass-chat-me, .glass-chat-them');
        if (!bubbleEl) return;

        let badge = bubbleEl.querySelector('.msg-reactions-badge');
        if (!reactions || Object.keys(reactions).length === 0) {
            if (badge) badge.remove();
            return;
        }

        if (!badge) {
            badge = document.createElement('div');
            const isMe = bubbleEl.classList.contains('glass-chat-me');
            badge.className = `msg-reactions-badge absolute -bottom-2.5 ${isMe ? 'right-2' : 'left-2'} bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-full px-1.5 py-0.5 shadow-sm text-[10px] flex items-center gap-1 select-none z-10`;
            bubbleEl.appendChild(badge);
        }

        let inner = '';
        for (const [emoji, count] of Object.entries(reactions)) {
            inner += `<span>${emoji}<span class="text-[8px] font-bold text-gray-400 ml-0.5">${count}</span></span>`;
        }
        badge.innerHTML = inner;
    }

    function renderSystemMessage(text) {
        chatContainer.insertAdjacentHTML('beforeend', `
            <div class="flex justify-center my-3 w-full animate-message">
                <span class="bg-gray-200/50 dark:bg-white/5 text-gray-500 dark:text-gray-400 text-[11px] px-3.5 py-1 font-semibold rounded-full border border-gray-300/30 dark:border-white/5 shadow-sm">${escapeHTML(text)}</span>
            </div>
        `);
        scrollArea.scrollTop = scrollArea.scrollHeight;
    }

    function updateTypingStatus(typers) {
        const otherTypers = typers.filter(name => name !== window.myGlobalAnonName);
        const statusEl = document.querySelector('#chat-header-name + div p');
        if (!statusEl) return;

        if (otherTypers.length === 0) {
            const countText = globalOnlineCount ? globalOnlineCount.textContent : '0 users online';
            statusEl.innerHTML = `<span class="flex items-center gap-1.5"><span class="online-pulse"></span> ${countText}</span>`;
        } else {
            let text = '';
            if (otherTypers.length === 1) {
                text = `${otherTypers[0]} is typing...`;
            } else if (otherTypers.length === 2) {
                text = `${otherTypers[0]} and ${otherTypers[1]} are typing...`;
            } else {
                text = 'Several people are typing...';
            }
            statusEl.innerHTML = `<span class="text-emerald-500 font-semibold italic animate-pulse">${escapeHTML(text)}</span>`;
        }
    }

    let typingTimeout = null;
    let isCurrentlyTyping = false;

    if (bottomAiInput) {
        bottomAiInput.addEventListener('input', () => {
            if (currentChat === '__global__') {
                if (!isCurrentlyTyping) {
                    isCurrentlyTyping = true;
                    sendGlobalTypingState(true);
                }
                clearTimeout(typingTimeout);
                typingTimeout = setTimeout(() => {
                    isCurrentlyTyping = false;
                    sendGlobalTypingState(false);
                }, 2000);
            }
        });
    }

    async function sendGlobalTypingState(isTyping) {
        try {
            await fetch('/api/global-chat/typing', {
                method: 'POST',
                headers: { 'content-type': 'application/json' },
                body: JSON.stringify({ isTyping })
            });
        } catch { }
    }

    // Event delegation for message actions (Reply, React, Delete)
    chatContainer.addEventListener('click', (e) => {
        const replyBtn = e.target.closest('.reply-btn');
        if (replyBtn) {
            const msgId = replyBtn.dataset.msgId;
            const sender = replyBtn.dataset.sender;
            const text = replyBtn.dataset.text;
            setupReply(msgId, sender, text);
            return;
        }

        const reactTrigger = e.target.closest('.react-trigger-btn');
        if (reactTrigger) {
            const msgId = reactTrigger.dataset.msgId;
            showReactionPicker(reactTrigger, msgId);
            return;
        }

        const delBtn = e.target.closest('.delete-msg-btn');
        if (delBtn) {
            const msgId = delBtn.dataset.msgId;
            if (!confirm('Delete this message for everyone in Global Chat?')) return;
            fetch(`/api/global-chat/messages/${msgId}`, { method: 'DELETE' })
                .then(r => r.json())
                .then(d => { if (!d.ok) alert(d.error || 'Failed to delete'); })
                .catch(err => console.error('[Delete Msg Error]', err));
            return;
        }
    });

    async function promptChangeGlobalAlias() {
        const currentName = window.myGlobalAnonName || '';
        const newAlias = prompt(`Set your Global Chat Handle / Nickname:\n(Only visible in Global Chat. Leave empty to use random animal name)`, currentName);
        if (newAlias === null) return;

        try {
            const r = await fetch('/api/global-chat/alias', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ alias: newAlias.trim() })
            });
            const d = await r.json();
            if (d.ok) {
                window.myGlobalAnonName = d.name;
                const aliasLabel = document.querySelector('#change-global-alias-btn span');
                if (aliasLabel) aliasLabel.textContent = `Alias: ${d.name}`;
            } else {
                alert(d.error || 'Failed to update alias');
            }
        } catch(err) {
            console.error('[promptChangeGlobalAlias]', err);
            alert('Error updating alias');
        }
    }

    function connectGlobalChat() {
        if (globalEventSource) return;

        chatContainer.innerHTML = `
            <div class="flex justify-center my-6 animate-pulse">
                <span class="bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 text-xs px-4 py-2 font-bold rounded-full shadow-sm border border-indigo-100 dark:border-indigo-900/40">Connecting to Global Chat...</span>
            </div>
        `;

        globalEventSource = new EventSource('/api/global-chat/stream');

        globalEventSource.addEventListener('init', (e) => {
            try {
                const data = JSON.parse(e.data);
                window.myGlobalAnonName = data.name;
                if (currentChat === '__global__' && headerName) {
                    headerName.innerHTML = `
                        <div class="flex items-center gap-2">
                            <span>Global Chat Room</span>
                            <button id="change-global-alias-btn" title="Set your custom anonymous handle" class="text-xs px-2 py-0.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-100 transition flex items-center gap-1 font-medium">
                                <span>Alias: ${escapeHTML(data.name)}</span>
                                <span class="text-[10px]">✏️</span>
                            </button>
                        </div>
                    `;
                    document.getElementById('change-global-alias-btn')?.addEventListener('click', promptChangeGlobalAlias);
                }
            } catch (err) { }
        });

        globalEventSource.addEventListener('history', (e) => {
            try {
                const msgs = JSON.parse(e.data);
                chatContainer.innerHTML = '';
                let lastDate = '';
                msgs.forEach(msg => {
                    if (msg.date !== lastDate) {
                        chatContainer.insertAdjacentHTML('beforeend', `
                            <div class="flex justify-center mb-6 w-full date-separator">
                                <span class="bg-[#E1F2FB] dark:bg-[#182229] text-[#54656f] dark:text-[#8696a0] text-[12.5px] px-3 py-1 rounded-lg shadow-sm font-medium">${formatChatDate(msg.date)}</span>
                            </div>
                        `);
                        lastDate = msg.date;
                    }
                    const bubble = renderGlobalMessage(msg);
                    chatContainer.insertAdjacentHTML('beforeend', bubble);
                });
                scrollArea.scrollTop = scrollArea.scrollHeight;
            } catch (err) {
                console.error('Failed to parse global chat history:', err);
            }
        });

        globalEventSource.addEventListener('message', (e) => {
            try {
                const msg = JSON.parse(e.data);
                const bubble = renderGlobalMessage(msg);
                chatContainer.insertAdjacentHTML('beforeend', bubble);
                scrollArea.scrollTop = scrollArea.scrollHeight;
            } catch (err) {
                console.error('Failed to parse incoming global message:', err);
            }
        });

        globalEventSource.addEventListener('clear', (e) => {
            chatContainer.innerHTML = '';
        });

        globalEventSource.addEventListener('online-list', (e) => {
            try {
                const users = JSON.parse(e.data);
                updateOnlineUsersList(users);
                if (currentChat === '__global__') {
                    const statusEl = document.querySelector('#chat-header-name + div p');
                    if (statusEl) {
                        statusEl.innerHTML = `<span class="flex items-center gap-1.5"><span class="online-pulse"></span> ${users.length} user${users.length === 1 ? '' : 's'} online</span>`;
                    }
                }
            } catch (err) {
                console.error('Failed to parse online users list:', err);
            }
        });

        globalEventSource.addEventListener('typing-list', (e) => {
            try {
                const typers = JSON.parse(e.data);
                updateTypingStatus(typers);
            } catch (err) { }
        });

        globalEventSource.addEventListener('system', (e) => {
            try {
                const sys = JSON.parse(e.data);
                renderSystemMessage(sys.text);
            } catch (err) { }
        });

        globalEventSource.addEventListener('reaction', (e) => {
            try {
                const data = JSON.parse(e.data);
                updateMessageReactionsInDOM(data.messageId, data.reactions);
            } catch (err) { }
        });

        globalEventSource.addEventListener('delete-message', (e) => {
            try {
                const data = JSON.parse(e.data);
                const msgEl = document.getElementById(`global-msg-${data.messageId}`);
                if (msgEl) {
                    msgEl.style.transition = 'all 0.2s ease-out';
                    msgEl.style.opacity = '0';
                    msgEl.style.transform = 'scale(0.95)';
                    setTimeout(() => msgEl.remove(), 200);
                }
            } catch (err) { }
        });

        globalEventSource.onerror = (err) => {
            console.error('Global EventSource error:', err);
        };

        if (globalActiveIndicator) globalActiveIndicator.classList.remove('hidden');
    }

    function disconnectGlobalChat() {
        if (globalEventSource) {
            globalEventSource.close();
            globalEventSource = null;
        }
        if (globalActiveIndicator) globalActiveIndicator.classList.add('hidden');
        window.clearReplyPreview();
    }

    function updateOnlineUsersList(users) {
        if (globalOnlineCount) {
            globalOnlineCount.textContent = `${users.length} user${users.length === 1 ? '' : 's'} online`;
        }
        if (!globalOnlineUsersList) return;
        globalOnlineUsersList.innerHTML = '';
        users.forEach(u => {
            const item = document.createElement('div');
            item.className = 'flex items-center gap-2 py-0.5';
            const displayName = u.name || 'Anonymous User';

            let avatarHtml = `<div class="w-4 h-4 rounded-full bg-indigo-500 text-white font-bold flex items-center justify-center text-[8px] shrink-0">${displayName.charAt(0).toUpperCase()}</div>`;

            item.innerHTML = `
                ${avatarHtml}
                <span class="truncate font-semibold text-gray-700 dark:text-gray-300 flex-1">${escapeHTML(displayName)}</span>
                <div class="w-1.5 h-1.5 rounded-full bg-green-500"></div>
            `;
            globalOnlineUsersList.appendChild(item);
        });
    }

    function renderGlobalMessage(msg) {
        const isMe = window.__USER__ && msg.userId === window.__USER__.id;
        const msgClass = isMe ? 'glass-chat-me ml-auto rounded-2xl rounded-tr-sm' : 'glass-chat-them mr-auto rounded-2xl rounded-tl-sm';
        const nameHtml = !isMe ? `<p class="sender-name text-[11px] font-bold mb-1 tracking-wide" style="color: ${getStringColor(msg.sender)}">${msg.sender}</p>` : '';

        let replyBlockHtml = '';
        if (msg.replyTo) {
            replyBlockHtml = `
                <div class="reply-block border-l-4 border-indigo-500 bg-black/5 dark:bg-white/5 px-2 py-1 rounded-md mb-1.5 text-xs select-none">
                    <p class="font-bold text-indigo-600 dark:text-indigo-400">${escapeHTML(msg.replyTo.sender)}</p>
                    <p class="text-gray-500 dark:text-gray-300 truncate">${escapeHTML(msg.replyTo.text)}</p>
                </div>
            `;
        }

        const contentHtml = `<p style="color:var(--msg-text)" class="text-[14px] leading-normal font-medium whitespace-pre-wrap break-words">${escapeHTML(msg.text)}</p>`;
        const timeVar = isMe ? '--msg-time-me' : '--msg-time-them';

        // Actions: reply, react & delete (for own messages)
        const actionsHtml = `
            <div class="msg-actions absolute top-1/2 -translate-y-1/2 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-opacity duration-150 flex items-center gap-1 z-30 ${isMe ? 'right-full mr-2 flex-row-reverse' : 'left-full ml-2'}">
                <button class="msg-action-btn reply-btn w-6 h-6 rounded-full bg-white dark:bg-gray-800 shadow-sm border border-gray-100 dark:border-gray-700 flex items-center justify-center text-gray-500 hover:text-indigo-600 transition" title="Reply" data-msg-id="${msg.id}" data-sender="${escapeHTML(msg.sender)}" data-text="${escapeHTML(msg.text)}">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M9 14L4 9l5-5"/><path d="M20 20v-7a4 4 0 0 0-4-4H4"/></svg>
                </button>
                <button class="msg-action-btn react-trigger-btn w-6 h-6 rounded-full bg-white dark:bg-gray-800 shadow-sm border border-gray-100 dark:border-gray-700 flex items-center justify-center text-gray-500 hover:text-amber-500 transition" title="React" data-msg-id="${msg.id}">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 21a9 9 0 1 1 0-18 9 9 0 0 1 0 18z"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
                </button>
                ${isMe || (window.__USER__ && (window.__USER__.is_admin === 1 || window.__USER__.is_admin === true)) ? `
                <button class="msg-action-btn delete-msg-btn w-6 h-6 rounded-full bg-white dark:bg-gray-800 shadow-sm border border-gray-100 dark:border-gray-700 flex items-center justify-center text-gray-500 hover:text-red-600 transition" title="Delete for everyone" data-msg-id="${msg.id}">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                </button>` : ''}
            </div>
        `;

        let reactionsHtml = '';
        if (msg.reactions && Object.keys(msg.reactions).length > 0) {
            reactionsHtml = `<div class="msg-reactions-badge absolute -bottom-2.5 ${isMe ? 'right-2' : 'left-2'} bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-full px-1.5 py-0.5 shadow-sm text-[10px] flex items-center gap-1 select-none z-10">`;
            for (const [emoji, count] of Object.entries(msg.reactions)) {
                reactionsHtml += `<span>${emoji}<span class="text-[8px] font-bold text-gray-400 ml-0.5">${count}</span></span>`;
            }
            reactionsHtml += `</div>`;
        }

        const ticksHtml = isMe ? `
            <svg class="w-3.5 h-3.5 ml-1 text-blue-500 inline-block align-middle" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M2 12l5.25 5 10.75-11" />
                <path d="M8 12l5.25 5 6.75-7" stroke-width="2.5" />
            </svg>
        ` : '';

        return `
            <div class="flex flex-col mb-3.5 w-full animate-message relative group" id="global-msg-${msg.id}">
                <div class="max-w-[80%] md:max-w-[70%] lg:max-w-[65%] relative px-3 py-1.5 md:px-3.5 md:py-2 ${msgClass} flex flex-col gap-0.5">
                    ${replyBlockHtml}
                    ${nameHtml}
                    ${contentHtml}
                    <div style="color:var(${timeVar})" class="text-[9px] flex items-center justify-end font-semibold mt-1 ml-auto select-none pt-0.5">
                        ${msg.time}
                        ${ticksHtml}
                    </div>
                    ${reactionsHtml}
                </div>
                ${actionsHtml}
            </div>
        `;
    }

    function escapeHTML(s) {
        return String(s || '').replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
        }[c]));
    }

    function deactivateGlobalUI() {
        disconnectGlobalChat();
        if (globalChatItem) {
            globalChatItem.classList.remove('bg-indigo-50', 'border-indigo-200', 'shadow-sm');
            globalChatItem.classList.add('hover:bg-gray-100', 'border-transparent');
        }
        if (globalOnlineUsersList) globalOnlineUsersList.classList.add('hidden');
        if (askAiBtn) askAiBtn.classList.remove('hidden');
        if (clearGlobalChatBtn) clearGlobalChatBtn.classList.add('hidden');
        if (bottomAiInput) {
            animatePlaceholder(bottomAiInput, `Continue With virtual ${otherPersonName}…`);
        }
        // Restore header to current chat's contact name
        if (headerName && otherPersonName) headerName.innerText = otherPersonName;
        const statusEl = document.querySelector('#chat-header-name + div p');
        if (statusEl) statusEl.innerText = 'online';

        // Show filters and search since they apply to private chats
        const filterBar = document.getElementById('filter-buttons-container');
        if (filterBar) filterBar.classList.remove('hidden');
        const searchBar = document.querySelector('.px-4.pt-3.pb-2.shrink-0.flex.gap-2.relative');
        if (searchBar) searchBar.classList.remove('hidden');
        const searchResults = document.getElementById('search-results');
        if (searchResults) searchResults.classList.remove('hidden');
        const smartFilters = document.getElementById('smart-filters-container');
        if (smartFilters) smartFilters.classList.add('hidden'); // remains hidden unless toggled
    }

    if (globalChatItem) {
        globalChatItem.addEventListener('click', () => {
            if (currentChat === '__global__') {
                if (window.innerWidth < 768 || window.kothaCompact) toggleSidebar(false);
                return;
            }

            disconnectGlobalChat();

            currentChat = '__global__';
            window.currentChat = '__global__';

            globalChatItem.classList.add('bg-indigo-50', 'border-indigo-200', 'shadow-sm');
            globalChatItem.classList.remove('hover:bg-gray-100', 'border-transparent');
            if (globalOnlineUsersList) globalOnlineUsersList.classList.remove('hidden');

            renderChatList(loadedChats, '');

            if (askAiBtn) askAiBtn.classList.add('hidden');
            if (window.__USER__ && (window.__USER__.is_admin === 1 || window.__USER__.is_admin === true)) {
                if (clearGlobalChatBtn) clearGlobalChatBtn.classList.remove('hidden');
            }
            if (headerName) {
                const myAlias = window.myGlobalAnonName || '';
                headerName.innerHTML = `
                    <div class="flex items-center gap-2">
                        <span>Global Chat Room</span>
                        <button id="change-global-alias-btn" title="Set your custom anonymous handle" class="text-xs px-2 py-0.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-100 transition flex items-center gap-1 font-medium">
                            <span>Alias: ${escapeHTML(myAlias || 'Set Alias')}</span>
                            <span class="text-[10px]">✏️</span>
                        </button>
                    </div>
                `;
                document.getElementById('change-global-alias-btn')?.addEventListener('click', promptChangeGlobalAlias);
            }
            if (sidebarTitle) sidebarTitle.innerText = 'Global Chat';
            const statusEl = document.querySelector('#chat-header-name + div p');
            if (statusEl) statusEl.innerText = 'Connecting...';

            if (bottomAiInput) {
                animatePlaceholder(bottomAiInput, 'Send a message to everyone…');
            }

            const aiChatContainer = document.getElementById('ai-chat-container');
            if (aiChatContainer) aiChatContainer.innerHTML = '';

            // Hide filters and search since they don't apply to global chat
            const filterBar = document.getElementById('filter-buttons-container');
            if (filterBar) filterBar.classList.add('hidden');
            const searchBar = document.querySelector('.px-4.pt-3.pb-2.shrink-0.flex.gap-2.relative');
            if (searchBar) searchBar.classList.add('hidden');
            const searchResults = document.getElementById('search-results');
            if (searchResults) searchResults.classList.add('hidden');
            const smartFilters = document.getElementById('smart-filters-container');
            if (smartFilters) smartFilters.classList.add('hidden');

            // Reset displayed messages so scroll/other filters don't operate on old data
            displayedMessages = [];
            allMessages = [];
            renderStart = 0;
            renderEnd = 0;

            connectGlobalChat();
            toggleSidebar(false);
        });
    }

    if (clearGlobalChatBtn) {
        clearGlobalChatBtn.addEventListener('click', async () => {
            if (!confirm('Are you sure you want to clear the entire global chat history? This cannot be undone.')) return;
            try {
                const resp = await fetch('/api/global-chat/clear', { method: 'DELETE' });
                if (!resp.ok) {
                    const err = await resp.json();
                    alert('Failed to clear global chat: ' + (err.error || resp.statusText));
                } else {
                    window.kothaToast('Global chat cleared');
                }
            } catch (err) {
                alert('Network error: ' + err.message);
            }
        });
    }

    // Initialize application by fetching the list of available chats
    loadChatsList();
    setTimeout(showOnboarding, 800);

    // Quick Action Listeners
    btnTop.addEventListener('click', () => {
        displayedMessages = allMessages; // Reset filter if active
        renderChats(0, Math.min(CHUNK_SIZE, displayedMessages.length));
        setTimeout(() => scrollArea.scrollTop = 0, 10);
        toggleSidebar(false);
    });

    btnBottom.addEventListener('click', () => {
        displayedMessages = allMessages;
        const end = displayedMessages.length;
        renderChats(Math.max(0, end - CHUNK_SIZE), end);
        setTimeout(() => scrollArea.scrollTop = scrollArea.scrollHeight, 10);
        toggleSidebar(false);
    });

    const openMediaGallery = () => {
        displayedMessages = allMessages.filter(msg => msg.attachment && msg.type !== 'system');
        renderChats(0, Math.min(CHUNK_SIZE, displayedMessages.length));
        statsInfo.innerHTML = `Showing <span class="font-bold text-indigo-600 dark:text-indigo-400">${displayedMessages.length}</span> media attachments.`;
        setTimeout(() => scrollArea.scrollTop = 0, 10);
        toggleSidebar(false);
    };
    if (btnMedia) btnMedia.addEventListener('click', openMediaGallery);

    const closeAnModal = () => {
        analyticsModal.classList.remove('opacity-100');
        analyticsModal.classList.add('opacity-0');
        setTimeout(() => analyticsModal.classList.add('hidden'), 300);
    };

    closeAnalytics.addEventListener('click', closeAnModal);
    analyticsModal.addEventListener('click', (e) => {
        if (e.target === analyticsModal) closeAnModal();
    });

    const openAnalyticsModal = () => {
        const totalMsgs = allMessages.filter(m => m.type !== 'system').length;
        const totalMedia = allMessages.filter(m => m.attachment && m.type !== 'system').length;
        const totalLinks = allMessages.filter(m => m.text && m.text.includes('http')).length;
        const firstDate = allMessages.find(m => m.date)?.date || '-';

        document.getElementById('stat-chat-title').innerText = `Chat with ${otherPersonName}`;
        document.getElementById('stat-total-msgs').innerText = totalMsgs.toLocaleString();
        document.getElementById('stat-total-media').innerText = totalMedia.toLocaleString();
        document.getElementById('stat-total-links').innerText = totalLinks.toLocaleString();
        document.getElementById('stat-first-date').innerText = firstDate;

        const senderCounts = {};
        allMessages.forEach(msg => {
            if (msg.sender && msg.type !== 'system') senderCounts[msg.sender] = (senderCounts[msg.sender] || 0) + 1;
        });

        let contributorsHtml = '';
        const sortedContributors = Object.entries(senderCounts).sort((a, b) => b[1] - a[1]).slice(0, 3);
        sortedContributors.forEach(([sName, count], idx) => {
            const pct = Math.round((count / totalMsgs) * 100);
            const colors = ['text-indigo-400 bg-indigo-500/10', 'text-pink-400 bg-pink-500/10', 'text-emerald-400 bg-emerald-500/10'];
            const barColors = ['bg-indigo-500', 'bg-pink-500', 'bg-emerald-500'];
            const cClass = colors[idx] || 'text-teal-400 bg-teal-500/10';
            const bColor = barColors[idx] || 'bg-teal-500';

            contributorsHtml += `
                <div>
                    <div class="flex justify-between items-center text-xs mb-1">
                        <span class="font-bold text-white/90 truncate max-w-[180px]">${sName}</span>
                        <span class="font-extrabold ${cClass} px-2 py-0.5 rounded text-[10px]">${count.toLocaleString()} (${pct}%)</span>
                    </div>
                    <div class="w-full h-1.5 rounded-full bg-white/5 overflow-hidden">
                        <div class="h-full ${bColor} rounded-full" style="width: ${pct}%"></div>
                    </div>
                </div>
            `;
        });
        document.getElementById('stat-contributors').innerHTML = contributorsHtml;

        // Hook up download/copy handlers
        const dlBtn = document.getElementById('stat-download-btn');
        const cpBtn = document.getElementById('stat-copy-btn');

        const showToast = (msg) => {
            if (window.kothaToast) window.kothaToast(msg);
            else console.log(msg);
        };

        const statsPayload = {
            contactName: otherPersonName,
            totalMsgs,
            totalMedia,
            totalLinks,
            firstDate,
            contributors: sortedContributors.map(([sName, count]) => {
                const pct = Math.round((count / totalMsgs) * 100);
                return [sName, count, pct];
            })
        };

        if (dlBtn) dlBtn.statsPayload = statsPayload;
        if (cpBtn) cpBtn.statsPayload = statsPayload;

        if (dlBtn && !dlBtn.hasListener) {
            dlBtn.hasListener = true;
            const handleDl = (e) => {
                e.stopPropagation();
                e.preventDefault();
                showToast('Generating stats card...');
                if (window.kothaExportStatsCard) {
                    window.kothaExportStatsCard(dlBtn.statsPayload, 'download');
                } else {
                    showToast('Export module not loaded yet');
                }
            };
            dlBtn.addEventListener('click', handleDl);
            dlBtn.addEventListener('touchend', (e) => {
                e.stopPropagation();
                e.preventDefault();
                handleDl(e);
            }, { passive: false });
        }

        if (cpBtn && !cpBtn.hasListener) {
            cpBtn.hasListener = true;
            const handleCp = (e) => {
                e.stopPropagation();
                e.preventDefault();
                showToast('Copying stats card...');
                if (window.kothaExportStatsCard) {
                    window.kothaExportStatsCard(cpBtn.statsPayload, 'copy');
                } else {
                    showToast('Export module not loaded yet');
                }
            };
            cpBtn.addEventListener('click', handleCp);
            cpBtn.addEventListener('touchend', (e) => {
                e.stopPropagation();
                e.preventDefault();
                handleCp(e);
            }, { passive: false });
        }

        toggleSidebar(false);
        analyticsModal.classList.remove('hidden');
        void analyticsModal.offsetWidth;
        analyticsModal.classList.remove('opacity-0');
        analyticsModal.classList.add('opacity-100');
    };
    if (btnAnalytics) btnAnalytics.addEventListener('click', openAnalyticsModal);

    // Explicit Button-Triggered Search Logic
    const searchResultsContainer = document.getElementById('search-results');

    searchBox.addEventListener('input', (e) => {
        const val = e.target.value.trim();
        const lowerVal = val.toLowerCase();
        
        if (val.length > 0) {
            searchClearBtn.classList.remove('hidden');
        } else {
            searchClearBtn.classList.add('hidden');
        }

        // Live filter chat list
        if (loadedChats && loadedChats.length > 0) {
            const filteredChats = loadedChats.filter(c => c.toLowerCase().includes(lowerVal));
            renderChatList(filteredChats, currentChat);
        }

        if (lowerVal.length < 2) {
            if (searchResultsContainer) searchResultsContainer.classList.add('hidden');
            if (resultsList) resultsList.innerHTML = '';
            return;
        }

        // Deep search in loaded messages
        const filteredMsgs = [];
        if (allMessages && allMessages.length > 0) {
            for (let i = 0; i < allMessages.length; i++) {
                if (allMessages[i].text && allMessages[i].text.toLowerCase().includes(lowerVal)) {
                    filteredMsgs.push(allMessages[i]);
                }
            }
        }

        if (statsInfo) {
            statsInfo.innerHTML = `Found <span class="font-bold text-indigo-600 dark:text-indigo-400">${filteredMsgs.length.toLocaleString()}</span> message matches.`;
        }

        if (resultsList) {
            if (filteredMsgs.length === 0) {
                resultsList.innerHTML = `<div class="text-xs text-gray-400 py-2 text-center">No message matches found</div>`;
            } else {
                let resultsHtml = '';
                const limitRes = filteredMsgs.slice(-50);
                const regex = new RegExp(`(${lowerVal.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
                limitRes.forEach(msg => {
                    const highlightedText = (msg.text || '').replace(regex, `<mark class="bg-yellow-200 text-gray-900 font-bold px-0.5 rounded">$1</mark>`);
                    resultsHtml += `
                        <div class="p-1.5 bg-white dark:bg-gray-800 hover:bg-indigo-50/50 dark:hover:bg-gray-700/50 shadow-xs cursor-pointer border border-gray-100 dark:border-gray-700 transition-all rounded-lg mb-1" onclick="jumpToMsg(${msg.id})">
                            <div class="flex justify-between items-center mb-0.5">
                                <span class="text-[10px] font-bold uppercase tracking-wide" style="color:${getStringColor(msg.sender)}">${msg.sender || 'User'}</span> 
                                <span class="text-[9px] text-gray-400 font-semibold">${msg.date || ''} ${msg.time || ''}</span>
                            </div>
                            <p class="text-[11px] text-gray-700 dark:text-gray-200 font-medium line-clamp-2 leading-relaxed">${highlightedText}</p>
                        </div>
                    `;
                });
                resultsList.innerHTML = resultsHtml;
            }
        }

        if (searchResultsContainer) {
            searchResultsContainer.classList.remove('hidden');
        }
    });

    searchClearBtn.addEventListener('click', () => {
        searchBox.value = '';
        searchClearBtn.classList.add('hidden');
        if (loadedChats) {
            renderChatList(loadedChats, currentChat);
        }
        if (searchResultsContainer) searchResultsContainer.classList.add('hidden');
        if (resultsList) resultsList.innerHTML = '';
        if (statsInfo) {
            statsInfo.innerHTML = `Loaded <span class="font-bold text-blue-600 dark:text-blue-400">${allMessages.length.toLocaleString()}</span> messages dynamically.`;
        }
    });

    // ── Dark Mode Toggle ──
    const darkBtn = document.getElementById('dark-mode-btn');
    const dmIcon = document.getElementById('dm-icon');
    function updateDmIcon() {
        if (!dmIcon) return;
        const isDark = document.documentElement.classList.contains('dark');
        dmIcon.innerHTML = isDark
            ? '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>'
            : '<path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/>';
        const meta = document.querySelector('meta[name="theme-color"]');
        if (meta) meta.content = isDark ? '#111b21' : '#f0f2f5';
    }

    function toggleTheme() {
        document.documentElement.classList.toggle('dark');
        const isDark = document.documentElement.classList.contains('dark');
        localStorage.setItem('kotha_dark', isDark ? '1' : '0');
        updateDmIcon();
        window.dispatchEvent(new CustomEvent('kotha-theme-change', { detail: { dark: isDark } }));
    }
    window.kothaToggleTheme = toggleTheme;

    if (darkBtn) {
        updateDmIcon(); // Set initial icon
        darkBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleTheme();
        });
    }

    window.jumpToMsg = (id) => {
        displayedMessages = allMessages; // Make sure we are in main view
        const idx = displayedMessages.findIndex(m => m.id === id);
        if (idx !== -1) {
            const start = Math.max(0, idx - 50);
            const end = Math.min(displayedMessages.length, idx + 100);
            renderChats(start, end);

            toggleSidebar(false);
            if (typeof closeSearchModal === 'function') closeSearchModal();

            setTimeout(() => {
                const el = document.getElementById(`msg-${id}`);
                if (el) {
                    scrollArea.scrollTop = el.offsetTop - (scrollArea.clientHeight / 2) + 50;
                    const bubble = el.firstElementChild;
                    if (bubble) {
                        bubble.style.transition = 'all 0.3s ease';
                        bubble.style.boxShadow = '0 0 0 3px rgba(250,204,21,0.6), 0 8px 24px -4px rgba(0,0,0,0.15)';
                        bubble.style.transform = 'scale(1.02)';
                        bubble.classList.add('search-result-flash');

                        // Highlight search query inside the message
                        const query = searchBox.value.trim();
                        if (query.length >= 3) {
                            const textEl = bubble.querySelector('p');
                            if (textEl && textEl.textContent.toLowerCase().includes(query.toLowerCase())) {
                                const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
                                textEl.innerHTML = textEl.textContent.replace(regex, '<mark class="search-highlight">$1</mark>');
                            }
                        }

                        setTimeout(() => {
                            bubble.style.boxShadow = '';
                            bubble.style.transform = '';
                            bubble.classList.remove('search-result-flash');
                            // Remove highlight marks after a while
                            setTimeout(() => {
                                const marks = bubble.querySelectorAll('mark.search-highlight');
                                marks.forEach(m => {
                                    m.outerHTML = m.textContent;
                                });
                            }, 3000);
                        }, 2500);
                    }
                }
            }, 100);
        }
    };

    // Hotkey: Press '/' to focus `#bottom-ai-input` on PC/desktop
    document.addEventListener('keydown', (e) => {
        if (e.key === '/') {
            const activeEl = document.activeElement;
            if (activeEl && (
                activeEl.tagName === 'INPUT' ||
                activeEl.tagName === 'TEXTAREA' ||
                activeEl.isContentEditable
            )) {
                return;
            }
            if (bottomAiInput) {
                e.preventDefault();
                bottomAiInput.focus();
            }
        }
    });

    // Expose chat data getters globally for features (like Chat Wrapped)
    window.kothaGetAllMessages = () => allMessages;
    window.kothaGetMyName = () => myName;
    window.kothaGetOtherPersonName = () => otherPersonName;
    window.kothaGetCurrentChat = () => currentChat;

    // ─── Auto-focus input on any keypress ───
    // When user starts typing anywhere, focus the chat input automatically
    document.addEventListener('keydown', (e) => {
        // Only act when a chat is open
        if (!currentChat) return;
        const inp = document.getElementById('bottom-ai-input');
        if (!inp) return;
        // Don't steal focus if already in an input/textarea/contenteditable
        const tag = (document.activeElement && document.activeElement.tagName) || '';
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
        if (document.activeElement && document.activeElement.isContentEditable) return;
        // Skip modifier-combos (Ctrl+A, Cmd+K, etc.) — only printable + Enter/Space/Backspace
        if (e.metaKey || e.ctrlKey || e.altKey) return;
        // Only act on printable keys (length 1) or Enter/Backspace
        const isPrintable = e.key.length === 1;
        const isEnter = e.key === 'Enter';
        const isBackspace = e.key === 'Backspace';
        if (!isPrintable && !isEnter && !isBackspace) return;
        // Focus the input — the keystroke itself will land in it
        inp.focus();
    });

    // ─── macOS Window: Drag + Traffic Lights (md+ only) ───
    (function initMacFrame() {
        const frame = document.getElementById('mac-frame');
        const titlebar = document.getElementById('mac-titlebar');
        if (!frame || !titlebar || window.innerWidth < 768) return;

        // --- Initialize square window position on desktop ---
        let inited = false;
        if (window.innerWidth >= 768) {
            const initialW = Math.max(850, Math.min(window.innerWidth * 0.85, 1000));
            const initialH = Math.min(window.innerHeight * 0.85, Math.max(700, initialW - 100)); // slightly rectangular
            frame.style.position = 'absolute';
            frame.style.width = initialW + 'px';
            frame.style.height = initialH + 'px';
            frame.style.left = ((window.innerWidth - initialW) / 2) + 'px';
            // Position above dock (bottom padding ~80px)
            frame.style.top = (window.innerHeight - initialH - 80) + 'px'; 
            frame.style.margin = '0';
            document.body.style.position = 'relative';
            inited = true;
        }

        function initPosition() {
            if (inited) return;
            inited = true;
            const r = frame.getBoundingClientRect();
            frame.style.position = 'absolute';
            frame.style.left = r.left + 'px';
            frame.style.top = r.top + 'px';
            frame.style.width = r.width + 'px';
            frame.style.height = r.height + 'px';
            frame.style.margin = '0';
            document.body.style.position = 'relative';
        }
        function resetPosition() {
            frame.style.position = '';
            frame.style.left = '';
            frame.style.top = '';
            frame.style.width = '';
            frame.style.height = '';
            frame.style.margin = '';
            document.body.style.position = '';
            frame.classList.remove('is-dragging');
            inited = false;
        }

        // --- Resize handles overlay (lives OUTSIDE the frame so it isn't clipped) ---
        const rhOverlay = document.createElement('div');
        rhOverlay.id = 'rh-overlay';
        const rhTpl = document.getElementById('resize-handles-tpl');
        if (rhTpl) rhOverlay.appendChild(rhTpl.content.cloneNode(true));
        document.body.appendChild(rhOverlay);
        function syncOverlay() {
            if (frame.classList.contains('mac-fullscreen') || frame.classList.contains('mac-minimized')) {
                rhOverlay.style.display = 'none';
                return;
            }
            const r = frame.getBoundingClientRect();
            rhOverlay.style.display = 'block';
            rhOverlay.style.left = r.left + 'px';
            rhOverlay.style.top = r.top + 'px';
            rhOverlay.style.width = r.width + 'px';
            rhOverlay.style.height = r.height + 'px';
        }
        syncOverlay();
        window.addEventListener('resize', syncOverlay);

        // --- Compact (phone-like) mode based on the FRAME's own width ---
        const sidebarEl = document.getElementById('sidebar');
        function updateCompact() {
            const compact = frame.getBoundingClientRect().width < 760;
            if (compact === !!window.kothaCompact) return;
            window.kothaCompact = compact;
            frame.classList.toggle('kompact', compact);
            if (compact) {
                // collapse sidebar into slide-in overlay
                if (sidebarEl) sidebarEl.classList.add('-translate-x-full');
            } else {
                if (sidebarEl) sidebarEl.classList.remove('-translate-x-full');
                const bd = document.getElementById('sidebar-backdrop');
                if (bd) bd.classList.add('hidden');
            }
        }
        if (window.ResizeObserver) {
            new ResizeObserver(updateCompact).observe(frame);
        }
        updateCompact();

        let dragging = false, sx, sy, sl, st;
        titlebar.addEventListener('mousedown', (e) => {
            if (e.target.closest('button')) return;
            if (frame.classList.contains('mac-fullscreen')) return;
            initPosition();
            dragging = true;
            sx = e.clientX; sy = e.clientY;
            sl = parseInt(frame.style.left); st = parseInt(frame.style.top);
            frame.classList.add('is-dragging');
            e.preventDefault();
        });
        document.addEventListener('mousemove', (e) => {
            if (!dragging) return;
            frame.style.left = Math.max(0, Math.min(window.innerWidth - 100, sl + (e.clientX - sx))) + 'px';
            frame.style.top = Math.max(0, Math.min(window.innerHeight - 60, st + (e.clientY - sy))) + 'px';
            syncOverlay();
        });
        document.addEventListener('mouseup', () => {
            if (!dragging) return;
            dragging = false;
            frame.classList.remove('is-dragging');
        });
        // Double-click titlebar to toggle fullscreen
        titlebar.addEventListener('dblclick', (e) => {
            if (e.target.closest('button')) return;
            document.getElementById('mac-fullscreen').click();
        });

        // --- Traffic light buttons ---
        const closeBtn = document.getElementById('mac-close');
        const minBtn = document.getElementById('mac-minimize');
        const fsBtn = document.getElementById('mac-fullscreen');
        const dock = document.getElementById('mac-dock');
        const dockIcon = document.getElementById('dock-kotha-icon');

        let minimized = false;
        let isAnimating = false;

        const dockDot = document.getElementById('dock-dot');

        function genieMinimize() {
            if (minimized || isAnimating) return;
            isAnimating = true;
            minimized = true;
            rhOverlay.style.display = 'none';
            frame.classList.remove('genie-restore');
            frame.classList.add('genie-minimize');
            if (dockDot) dockDot.style.opacity = '0';
            if (dock) dock.style.removeProperty('display'); // Make sure dock is shown on minimize
            setTimeout(() => {
                frame.classList.add('mac-minimized');
                frame.classList.remove('genie-minimize');
                isAnimating = false;
            }, 500);
        }

        function genieRestore() {
            if (!minimized || isAnimating) return;
            isAnimating = true;
            minimized = false;
            frame.classList.remove('mac-minimized', 'genie-minimize');
            frame.classList.add('genie-restore');
            if (dockDot) dockDot.style.opacity = '1';
            
            // If restoring while still in fullscreen mode, keep dock hidden, otherwise show it
            if (dock) {
                if (frame.classList.contains('mac-fullscreen')) {
                    dock.style.setProperty('display', 'none', 'important');
                } else {
                    dock.style.removeProperty('display');
                }
            }

            if (dockIcon) {
                dockIcon.classList.add('dock-bounce');
                setTimeout(() => dockIcon.classList.remove('dock-bounce'), 600);
            }
            setTimeout(() => {
                frame.classList.remove('genie-restore');
                syncOverlay();
                isAnimating = false;
            }, 450);
        }

        if (closeBtn) closeBtn.addEventListener('click', () => {
            window.location.href = '/';
        });
        if (minBtn) minBtn.addEventListener('click', genieMinimize);
        if (fsBtn) fsBtn.addEventListener('click', () => {
            const isFs = frame.classList.toggle('mac-fullscreen');
            if (isFs) {
                resetPosition();
                if (dock) dock.style.setProperty('display', 'none', 'important');
            } else {
                if (dock) dock.style.removeProperty('display');
            }
            requestAnimationFrame(syncOverlay);
        });

        // Dock icon click toggles minimize/restore
        if (dockIcon) dockIcon.addEventListener('click', () => {
            if (minimized) genieRestore(); else genieMinimize();
        });

        // --- All-side resize handles (attached to the outside overlay) ---
        {
            const MIN_W = 380, MIN_H = 400;
            rhOverlay.querySelectorAll('.rh').forEach(handle => {
                const dir = handle.dataset.dir;
                handle.addEventListener('mousedown', (e) => {
                    if (frame.classList.contains('mac-fullscreen')) return;
                    initPosition();
                    e.preventDefault();
                    e.stopPropagation();
                    const startX = e.clientX, startY = e.clientY;
                    const rect = frame.getBoundingClientRect();
                    const startL = rect.left, startT = rect.top, startW = rect.width, startH = rect.height;

                    const SNAP = 20; // px — magnetic catch distance to screen edges
                    function onMove(ev) {
                        const dx = ev.clientX - startX, dy = ev.clientY - startY;
                        let l = startL, t = startT, w = startW, h = startH;
                        const vw = window.innerWidth, vh = window.innerHeight;

                        if (dir.includes('e')) {
                            w = Math.max(MIN_W, startW + dx);
                            if (Math.abs((l + w) - vw) <= SNAP) w = vw - l; // snap right edge
                        }
                        if (dir.includes('w')) {
                            w = Math.max(MIN_W, startW - dx); l = startL + startW - w;
                            if (Math.abs(l) <= SNAP) { w += l; l = 0; } // snap left edge
                        }
                        if (dir.includes('s')) {
                            h = Math.max(MIN_H, startH + dy);
                            if (Math.abs((t + h) - vh) <= SNAP) h = vh - t; // snap bottom edge
                        }
                        if (dir.includes('n')) {
                            h = Math.max(MIN_H, startH - dy); t = startT + startH - h;
                            if (Math.abs(t) <= SNAP) { h += t; t = 0; } // snap top edge
                        }

                        frame.style.left = l + 'px';
                        frame.style.top = t + 'px';
                        frame.style.width = w + 'px';
                        frame.style.height = h + 'px';
                        syncOverlay();
                    }
                    function onUp() {
                        document.removeEventListener('mousemove', onMove);
                        document.removeEventListener('mouseup', onUp);
                    }
                    document.addEventListener('mousemove', onMove);
                    document.addEventListener('mouseup', onUp);
                });
            });
        }
    })();


    // --- Group Roles Logic ---
    window.openRolesModal = (senders, chatName) => {
        const modal = document.getElementById('group-roles-modal');
        const mySelect = document.getElementById('roles-my-name');
        const aiSelect = document.getElementById('roles-ai-name');
        
        mySelect.innerHTML = '';
        aiSelect.innerHTML = '';
        
        senders.forEach(sender => {
            const opt1 = document.createElement('option');
            opt1.value = sender; opt1.textContent = sender;
            const opt2 = document.createElement('option');
            opt2.value = sender; opt2.textContent = sender;
            mySelect.appendChild(opt1);
            aiSelect.appendChild(opt2);
        });

        // Set defaults from current logic
        mySelect.value = myName;
        aiSelect.value = otherPersonName;

        modal.classList.remove('hidden');
        setTimeout(() => modal.classList.remove('opacity-0'), 10);

        document.getElementById('close-roles-modal').onclick = () => {
            modal.classList.add('opacity-0');
            setTimeout(() => modal.classList.add('hidden'), 300);
        };

        document.getElementById('save-roles-btn').onclick = () => {
            const selectedMyName = mySelect.value;
            const selectedAiName = aiSelect.value;
            
            localStorage.setItem('roles_' + chatName, JSON.stringify({
                myName: selectedMyName,
                aiName: selectedAiName
            }));
            
            modal.classList.add('opacity-0');
            setTimeout(() => modal.classList.add('hidden'), 300);
            
            // Reload the chat to apply new roles immediately
            if (typeof window.refreshChats === 'function') {
                window.refreshChats(chatName);
            } else {
                window.location.reload();
            }
        };
    };

});
