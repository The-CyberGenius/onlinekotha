const parser = require('../../server/parser.js');
console.log('Parser ready');
