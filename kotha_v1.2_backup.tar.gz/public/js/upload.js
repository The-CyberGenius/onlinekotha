(function () {
    const modal = document.getElementById('upload-modal');
    const openBtn = document.getElementById('open-upload-btn');
    const closeBtn = document.getElementById('close-upload');
    const dropZone = document.getElementById('drop-zone');
    const pickZipBtn = document.getElementById('pick-zip-btn');
    const pickFolderBtn = document.getElementById('pick-folder-btn');
    const fileInputZip = document.getElementById('file-input-zip');
    const fileInputFolder = document.getElementById('file-input-folder');
    const progressWrap = document.getElementById('upload-progress');
    const progressBar = document.getElementById('upload-bar');
    const progressPercent = document.getElementById('upload-percent');
    const progressStatus = document.getElementById('upload-status-text');
    const errorEl = document.getElementById('upload-error');

    if (!modal || !openBtn) return;

    function openModal() {
        if (window.__IS_GUEST__) {
            const guestStatus = window.__GUEST_STATUS__ || {};
            if ((guestStatus.chatsRemaining ?? 1) <= 0) {
                if (window.openAuthModal) {
                    window.openAuthModal('Guest limit reached (1/1 free chat imported). Please sign in with Google to import more chats!');
                }
                return;
            }
        }
        modal.classList.remove('hidden');
        requestAnimationFrame(() => modal.classList.remove('opacity-0'));
        resetUI();
    }

    function closeModal() {
        modal.classList.add('opacity-0');
        setTimeout(() => modal.classList.add('hidden'), 200);
    }

    function resetUI() {
        progressWrap.classList.add('hidden');
        errorEl.classList.add('hidden');
        errorEl.textContent = '';
        progressBar.style.width = '0%';
        progressPercent.textContent = '0%';
        progressStatus.textContent = 'Uploading...';
    }

    function showError(msg) {
        errorEl.textContent = msg;
        errorEl.classList.remove('hidden');
        progressWrap.classList.add('hidden');
    }

    openBtn.addEventListener('click', openModal);
    closeBtn.addEventListener('click', closeModal);
    modal.addEventListener('click', e => {
        if (e.target === modal) closeModal();
    });

    pickZipBtn.addEventListener('click', () => fileInputZip.click());
    pickFolderBtn.addEventListener('click', () => fileInputFolder.click());

    fileInputZip.addEventListener('change', e => {
        if (e.target.files.length) uploadFiles(Array.from(e.target.files));
    });
    fileInputFolder.addEventListener('change', e => {
        if (e.target.files.length) uploadFiles(Array.from(e.target.files));
    });

    ['dragenter', 'dragover'].forEach(evt => {
        dropZone.addEventListener(evt, e => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.classList.add('bg-indigo-100/80', 'border-indigo-500');
        });
    });

    ['dragleave', 'drop'].forEach(evt => {
        dropZone.addEventListener(evt, e => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.classList.remove('bg-indigo-100/80', 'border-indigo-500');
        });
    });

    dropZone.addEventListener('drop', async e => {
        const items = e.dataTransfer.items;
        const files = [];

        if (items && items.length && items[0].webkitGetAsEntry) {
            const entries = [];
            for (let i = 0; i < items.length; i++) {
                const entry = items[i].webkitGetAsEntry();
                if (entry) entries.push(entry);
            }
            for (const entry of entries) {
                await walkEntry(entry, '', files);
            }
        } else {
            for (const f of e.dataTransfer.files) files.push(f);
        }

        if (files.length) uploadFiles(files);
    });

    function walkEntry(entry, pathPrefix, out) {
        return new Promise(resolve => {
            if (entry.isFile) {
                entry.file(file => {
                    const wrapped = new File([file], pathPrefix + file.name, { type: file.type });
                    Object.defineProperty(wrapped, 'webkitRelativePath', {
                        value: pathPrefix + file.name,
                    });
                    out.push(wrapped);
                    resolve();
                }, resolve);
            } else if (entry.isDirectory) {
                const reader = entry.createReader();
                const readAll = (collected = []) => {
                    reader.readEntries(async batch => {
                        if (!batch.length) {
                            for (const child of collected) {
                                await walkEntry(child, pathPrefix + entry.name + '/', out);
                            }
                            resolve();
                        } else {
                            readAll(collected.concat(Array.from(batch)));
                        }
                    }, resolve);
                };
                readAll();
            } else {
                resolve();
            }
        });
    }

    // ── Paste chat text ──────────────────────────────────────
    const togglePasteBtn = document.getElementById('toggle-paste-btn');
    const pasteArea      = document.getElementById('paste-area');
    const pasteText      = document.getElementById('paste-text');
    const pasteImportBtn = document.getElementById('paste-import-btn');

    if (togglePasteBtn && pasteArea) {
        togglePasteBtn.addEventListener('click', () => {
            pasteArea.classList.toggle('hidden');
            if (!pasteArea.classList.contains('hidden')) pasteText?.focus();
        });
    }
    if (pasteImportBtn) {
        pasteImportBtn.addEventListener('click', () => {
            const text = (pasteText?.value || '').trim();
            if (!text) { showError('Paste some chat text first.'); return; }
            // Wrap into a _chat.txt File and reuse the normal upload pipeline
            const file = new File([text], '_chat.txt', { type: 'text/plain' });
            uploadFiles([file]);
        });
    }

    async function uploadFiles(files) {
        if (window.__IS_GUEST__) {
            const guestStatus = window.__GUEST_STATUS__ || {};
            if ((guestStatus.chatsRemaining ?? 1) <= 0) {
                closeModal();
                if (window.openAuthModal) {
                    window.openAuthModal('Guest limit reached (1/1 free chat imported). Please sign in with Google to import more chats!');
                }
                return;
            }
        }

        let totalSize = 0;
        for (const f of files) {
            totalSize += f.size;
        }
        if (totalSize > 650 * 1024 * 1024) {
            showError("Chat file is too large (over 650MB). Please export your chat 'Without Media' in WhatsApp and try again.");
            return;
        }

        resetUI();
        progressWrap.classList.remove('hidden');
        progressStatus.textContent = 'Preparing file...';

        const form = new FormData();
        for (const f of files) {
            let relPath = f.webkitRelativePath || f.name;
            // Fix iOS Safari / Busboy bug: emojis or non-ASCII in filenames can break multipart parsing
            if (files.length === 1 && f.name.toLowerCase().endsWith('.zip')) {
                relPath = 'whatsapp_chat.zip';
            } else {
                relPath = relPath.replace(/[^\x20-\x7E]/g, ''); // strip non-ASCII
            }
            
            // CRITICAL iOS WebKit FIX: 
            // - If we use f.slice(), it doesn't strip the corrupted emoji filename metadata in WebKit, causing 400 errors.
            // - If we use FileReader for a 600MB file, WebKit crashes due to Out of Memory.
            // SOLUTION: Buffer into memory for normal-sized chats to strip emojis safely, 
            // but use f.slice() for massive chats (which likely don't have emoji names anyway or user exported with media).
            let safeBlob;
            if (f.size <= 100 * 1024 * 1024) {
                const arrayBuffer = await new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = e => resolve(e.target.result);
                    reader.onerror = reject;
                    reader.readAsArrayBuffer(f);
                });
                safeBlob = new Blob([arrayBuffer], { type: f.type });
            } else {
                safeBlob = f.slice(0, f.size, f.type);
            }
            form.append('files', safeBlob, relPath);
        }

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/upload');

        xhr.upload.addEventListener('progress', e => {
            if (e.lengthComputable) {
                const pct = Math.round((e.loaded / e.total) * 100);
                progressBar.style.width = pct + '%';
                progressPercent.textContent = pct + '%';
                if (pct === 100) progressStatus.textContent = 'Processing on server...';
            }
        });

        xhr.onload = () => {
            if (xhr.status === 413) {
                showError('File too large — max 650 MB');
                return;
            }
            try {
                const resp = JSON.parse(xhr.responseText);
                if (xhr.status >= 200 && xhr.status < 300 && resp.ok) {
                    progressStatus.textContent = 'Done!';
                    if (window.__IS_GUEST__ && window.__GUEST_STATUS__) {
                        window.__GUEST_STATUS__.chatsRemaining = Math.max(0, (window.__GUEST_STATUS__.chatsRemaining || 1) - 1);
                        window.__GUEST_STATUS__.chatsImported = (window.__GUEST_STATUS__.chatsImported || 0) + 1;
                        const remEl = document.getElementById('guest-chat-rem');
                        if (remEl) remEl.textContent = window.__GUEST_STATUS__.chatsRemaining;
                    }
                    setTimeout(() => {
                        closeModal();
                        if (window.refreshChats) window.refreshChats(resp.chat);
                        else window.location.reload();
                    }, 400);
                } else if (resp.requireAuth || xhr.status === 403) {
                    closeModal();
                    if (window.openAuthModal) {
                        window.openAuthModal(resp.error || 'Guest limit reached (1/1 free chat imported). Please sign in with Google to import more chats!');
                    }
                } else {
                    showError(resp.error || 'Upload failed');
                }
            } catch (err) {
                showError('Server error (' + xhr.status + ')');
            }
        };

        xhr.onerror = () => showError('Network error');
        xhr.send(form);
    }

    // ── Share Target: file shared from WhatsApp → PWA ────────
    // The service worker stashes the shared file in a Cache and redirects to
    // /app?shared=1. We pick it up here and run the normal import.
    async function handleSharedFile() {
        if (!new URLSearchParams(location.search).has('shared')) return;
        try {
            const cache = await caches.open('kotha-share');
            const res = await cache.match('/__shared_chat');
            if (res) {
                const blob = await res.blob();
                const name = res.headers.get('x-filename') || 'shared_chat.zip';
                const file = new File([blob], name, { type: blob.type || 'application/zip' });
                await cache.delete('/__shared_chat');
                openModal();
                uploadFiles([file]);
            }
        } catch (e) { /* no shared file */ }
        // Clean the URL
        history.replaceState({}, '', '/app');
    }
    handleSharedFile();
})();
