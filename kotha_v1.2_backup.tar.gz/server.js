require('dotenv').config();
const express = require('express');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const dmUploadDir = path.join(__dirname, 'public', 'uploads', 'dm');
if (!fs.existsSync(dmUploadDir)) fs.mkdirSync(dmUploadDir, { recursive: true });
const dmUpload = multer({
    storage: multer.diskStorage({
        destination: dmUploadDir,
        filename: (req, file, cb) => cb(null, `dm_${Date.now()}_${Math.random().toString(36).slice(2,8)}_${file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_')}`)
    }),
    limits: { fileSize: 50 * 1024 * 1024 }
});

const { db } = require('./server/db');
const {
    authMiddleware,
    requireUser,
    createUser,
    createSession,
    login,
    logout,
    effectivePlan,
    getSession,
} = require('./server/auth');
const { getMessages } = require('./server/cache');
const { upload, handleUpload, SRC_DIR, userDir } = require('./server/upload');
const { findChatFile } = require('./server/parser');
const { countWords, checkBurstLimit } = require('./server/rateLimit');
const adminRouter = require('./server/admin');
const aiRouter = require('./server/ai');
const globalChatRouter = require('./server/globalChat');
const contactRouter = require('./server/contact');
const emailModule = require('./server/email');
const { sendVerifyEmail, sendPasswordResetEmail, consumeToken } = emailModule;

const { router: dodoRouter, webhookHandler: dodoWebhookHandler } = require('./server/dodo');
const { router: oauthRouter } = require('./server/oauth');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const geoip = require('geoip-lite');

process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
});
process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

const http = require('http');
const { Server: SocketIO } = require('socket.io');

const IS_PROD = process.env.NODE_ENV === 'production';

const app = express();
const httpServer = http.createServer(app);
const io = new SocketIO(httpServer, {
    cors: {
        origin: IS_PROD
            ? ['https://onlinekotha.com', 'https://www.onlinekotha.com']
            : ['http://localhost:3000', 'http://127.0.0.1:3000'],
        methods: ['GET', 'POST'],
        credentials: true
    }
});
app.set('io', io);

// Trust proxy for rate limiter (running behind Nginx)
app.set('trust proxy', 1);

const PORT = process.env.PORT || 3000;

// Shared cookie options — must be identical for set and clear
const COOKIE_OPTS = {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    ...(IS_PROD && { secure: true }),
};

if (!fs.existsSync(SRC_DIR)) fs.mkdirSync(SRC_DIR, { recursive: true });

// ---------- Security & Middlewares ----------
app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false,
}));
app.use(compression({
    filter: (req, res) => {
        if (req.headers['accept'] && req.headers['accept'].includes('text/event-stream')) {
            return false;
        }
        return compression.filter(req, res);
    }
}));
app.use(cookieParser());

// Payment webhooks need the raw body for signature verification — must come BEFORE express.json()
app.post('/api/webhooks/dodo', express.raw({ type: 'application/json' }), dodoWebhookHandler);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(authMiddleware);

const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 60,
    validate: false,
});

const contactLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 10,
    message: { error: 'Too many contact requests. Please try again later.' },
    validate: false,
});


app.use('/api', (req, res, next) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    next();
});

// ---------- Auth routes ----------
// Self-serve Signup with Name, Email, 6-Digit PIN, and Optional Phone
app.post('/api/auth/signup', authLimiter, async (req, res) => {
    try {
        const { email, pin, password, name, display_name, phone, phone_country_code } = req.body || {};
        if (!email) return res.status(400).json({ error: 'Email is required' });
        
        const cleanEmail = email.toLowerCase().trim();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
            return res.status(400).json({ error: 'Please enter a valid email address' });
        }

        const authSecret = (pin || password || '').trim();
        if (!authSecret || authSecret.length < 4) {
            return res.status(400).json({ error: 'Please enter a 4 to 6-digit PIN' });
        }

        const ip = req.ip || req.socket.remoteAddress;
        let country = null;
        if (ip) {
            try {
                const geo = geoip.lookup(ip);
                if (geo) country = geo.country;
            } catch {}
        }

        const user = createUser(cleanEmail, authSecret, {
            display_name: name || display_name,
            phone,
            phone_country_code,
            ip,
            country,
        });

        // Claim guest data if guest was active
        const { claimGuestData } = require('./server/guest');
        const guestId = req.cookies && req.cookies.kotha_guest_id;
        if (guestId) claimGuestData(guestId, user.id);

        const { token, expiresAt } = createSession(user.id);
        res.cookie('session', token, { ...COOKIE_OPTS, expires: new Date(expiresAt) });
        res.json({ ok: true, user });
    } catch (err) {
        res.status(400).json({ error: err.message || 'Signup failed' });
    }
});

app.get('/api/auth/verify', (req, res) => {
    const token = req.query.token;
    const row = consumeToken(token, 'verify');
    if (!row) return res.redirect('/verify-failed.html');
    db.prepare('UPDATE users SET email_verified = 1 WHERE id = ?').run(row.user_id);
    res.redirect('/verify-success.html');
});

app.post('/api/auth/forgot', async (req, res) => {
    const { email } = req.body || {};
    if (!email) return res.status(400).json({ error: 'email required' });
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase().trim());
    // Always return ok (don't leak which emails exist)
    if (user) {
        sendPasswordResetEmail(user).catch(err => console.error('reset email failed:', err.message));
    }
    res.json({ ok: true });
});

app.post('/api/auth/reset', async (req, res) => {
    const { token, password } = req.body || {};
    if (!token || !password) return res.status(400).json({ error: 'token + password required' });
    if (password.length < 4) return res.status(400).json({ error: 'PIN min 4 chars' });
    const row = consumeToken(token, 'reset');
    if (!row) return res.status(400).json({ error: 'Invalid or expired link' });
    const hash = bcrypt.hashSync(password, 10);
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, row.user_id);
    // Invalidate all sessions for security
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(row.user_id);
    res.json({ ok: true });
});

app.post('/api/auth/resend-verify', (req, res) => {
    if (!req.user) return res.status(401).json({ error: 'Login required' });
    const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
    if (u.email_verified) return res.json({ ok: true, already: true });
    sendVerifyEmail(u).catch(err => console.error('verify resend failed:', err.message));
    res.json({ ok: true });
});

app.post('/api/auth/login', authLimiter, (req, res) => {
    try {
        const { email, pin, password } = req.body || {};
        if (!email) return res.status(400).json({ error: 'Email is required' });
        const pass = (pin || password || '').trim();
        if (!pass) return res.status(400).json({ error: '6-digit PIN or password required' });

        const { token, expiresAt } = login(email.trim(), pass);

        // Claim guest data if guest was active
        const { claimGuestData } = require('./server/guest');
        const guestId = req.cookies && req.cookies.kotha_guest_id;
        const row = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase().trim());
        if (guestId && row) claimGuestData(guestId, row.id);

        res.cookie('session', token, { ...COOKIE_OPTS, expires: new Date(expiresAt) });
        res.json({ ok: true });
    } catch (err) {
        res.status(401).json({ error: err.message || 'Invalid email or PIN' });
    }
});

app.post('/api/auth/logout', (req, res) => {
    const token = req.cookies && req.cookies.session;
    logout(token);
    res.clearCookie('session', COOKIE_OPTS);
    res.json({ ok: true });
});

// OAuth routes (Google) — mounted under /api/auth so they sit alongside the rest
app.use('/api/auth', oauthRouter);

const { requireUserOrGuest } = require('./server/auth');
const { getGuestStatus, getOrCreateGuestId } = require('./server/guest');

app.get('/api/auth/me', (req, res) => {
    const guestStatus = getGuestStatus(req, res);
    if (!req.user) {
        return res.json({
            user: null,
            is_guest: true,
            guest: guestStatus,
        });
    }
    res.json({
        user: {
            ...req.user,
            effective_plan: effectivePlan(req.user),
        },
        is_guest: false,
        guest: guestStatus,
    });
});

app.post('/api/user/profile', requireUser, (req, res) => {
    const { display_name, phone, phone_country_code } = req.body || {};
    const updates = [];
    const params = [];

    if (typeof display_name === 'string') {
        updates.push('display_name = ?');
        params.push(display_name.trim() || null);
    }
    if (typeof phone === 'string') {
        updates.push('phone = ?');
        params.push(phone.trim() || null);
    }
    if (typeof phone_country_code === 'string') {
        updates.push('phone_country_code = ?');
        params.push(phone_country_code.trim() || '+91');
    }
    updates.push('phone_prompted = 1');

    params.push(req.user.id);
    db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...params);

    const updated = db.prepare('SELECT id, email, display_name, avatar_url, phone, phone_country_code, phone_prompted FROM users WHERE id = ?').get(req.user.id);
    res.json({ ok: true, user: updated });
});

app.post('/api/user/profile/skip', requireUser, (req, res) => {
    db.prepare('UPDATE users SET phone_prompted = 1 WHERE id = ?').run(req.user.id);
    res.json({ ok: true });
});

// ---------- Admin (must come BEFORE static so /admin routes aren't shadowed) ----------
app.use('/api/admin', adminRouter);

// /admin → redirect to /admin.html
app.get('/admin', (req, res) => res.redirect('/admin.html'));

// /app → main viewer (app.html). Allows both authenticated users & guests!
app.get('/app', (req, res) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.sendFile(path.join(__dirname, 'public', 'app.html'));
});

// Share Target fallback — if the service worker isn't active yet, the shared
// POST hits the server. Just bounce into the app (SW handles it once installed).
app.post('/share-target', (req, res) => res.redirect('/app'));
app.get('/share-target', (req, res) => res.redirect('/app'));

// Health check
app.get('/healthz', (req, res) => res.json({ ok: true, time: Date.now() }));

// Static frontend (landing /, login, admin, css, js, etc.) with caching
app.get('/', (req, res, next) => {
    const ua = req.headers['user-agent'] || '';
    if (ua.includes('OnlineKothaApp')) {
        if (req.user) {
            return res.redirect('/app');
        }
        return res.redirect('/login');
    }
    next();
});

app.use(express.static(path.join(__dirname, 'public'), {
    maxAge: '365d',
    etag: true,
    dotfiles: 'allow',
    setHeaders: (res, filePath) => {
        if (filePath.endsWith('.html')) {
            res.setHeader('Cache-Control', 'no-cache, must-revalidate');
        } else {
            res.setHeader('Vary', 'Accept-Encoding');
        }
    }
}));


// Helper to get storage directory for either User or Guest
function getOwnerId(req, res) {
    if (req.user) return req.user.id;
    return getOrCreateGuestId(req, res);
}

// Media: serve only the requesting user's files
app.get('/media/*rest', requireUserOrGuest, (req, res, next) => {
    const ownerId = getOwnerId(req, res);
    const rel = Array.isArray(req.params.rest)
        ? req.params.rest.join('/')
        : req.params.rest;
    const userRel = `u_${ownerId}/${rel}`;
    const fullPath = path.resolve(SRC_DIR, userRel);

    const userBase = path.resolve(SRC_DIR, `u_${ownerId}`);
    if (!fullPath.startsWith(userBase)) return res.status(403).end();

    if (!fs.existsSync(fullPath)) return res.status(404).end();

    const ext = path.extname(fullPath).toLowerCase();
    const MIME_MAP = {
        '.mp4': 'video/mp4', '.mov': 'video/mp4', '.m4v': 'video/mp4',
        '.webm': 'video/webm', '.3gp': 'video/3gpp',
        '.mkv': 'video/x-matroska', '.avi': 'video/x-msvideo',
        '.m4a': 'audio/mp4', '.aac': 'audio/aac',
        '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg',
        '.opus': 'audio/ogg; codecs=opus', '.wav': 'audio/wav',
        '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
        '.png': 'image/png', '.gif': 'image/gif',
        '.webp': 'image/webp', '.heic': 'image/heic',
        '.svg': 'image/svg+xml', '.svgz': 'image/svg+xml',
    };

    const mime = MIME_MAP[ext];
    const isVideo = mime && mime.startsWith('video/');

    if (isVideo) {
        const stat = fs.statSync(fullPath);
        const fileSize = stat.size;
        const rangeHeader = req.headers.range;

        if (rangeHeader) {
            const parts = rangeHeader.replace(/bytes=/, '').split('-');
            const start = parseInt(parts[0], 10);
            const end = parts[1] ? parseInt(parts[1], 10) : Math.min(start + 10 * 1024 * 1024 - 1, fileSize - 1);
            const chunkSize = end - start + 1;
            res.writeHead(206, {
                'Content-Range': `bytes ${start}-${end}/${fileSize}`,
                'Accept-Ranges': 'bytes',
                'Content-Length': chunkSize,
                'Content-Type': mime,
            });
            fs.createReadStream(fullPath, { start, end }).pipe(res);
        } else {
            res.writeHead(200, {
                'Content-Length': fileSize,
                'Content-Type': mime,
                'Accept-Ranges': 'bytes',
            });
            fs.createReadStream(fullPath).pipe(res);
        }
        return;
    }

    if (mime) res.setHeader('Content-Type', mime);
    res.sendFile(fullPath);
});

// ---------- Chats API (user or guest scoped) ----------
app.get('/api/chats', requireUserOrGuest, (req, res) => {
    const ownerId = getOwnerId(req, res);
    const myDir = userDir(ownerId);
    if (!fs.existsSync(myDir)) return res.json([]);
    
    let deletedSet = new Set();
    let dbChats = [];
    if (req.user) {
        dbChats = db.prepare('SELECT folder_name, created_at, deleted_by_user FROM chats WHERE user_id = ?').all(req.user.id);
        const deletedRows = dbChats.filter(r => r.deleted_by_user === 1);
        deletedSet = new Set(deletedRows.map(r => r.folder_name));
    } else {
        dbChats = db.prepare('SELECT folder_name, created_at FROM chats WHERE guest_id = ?').all(ownerId);
    }
    
    const timeMap = {};
    for (const r of dbChats) timeMap[r.folder_name] = r.created_at || 0;

    const folders = fs
        .readdirSync(myDir, { withFileTypes: true })
        .filter(d => d.isDirectory())
        .map(d => d.name)
        .filter(name => {
            if (req.user && !req.user.is_impersonating && deletedSet.has(name)) return false;
            const dir = path.join(myDir, name);
            return !!findChatFile(dir);
        })
        .sort((a, b) => {
            const timeA = timeMap[a] || 0;
            const timeB = timeMap[b] || 0;
            return timeA - timeB; // Oldest first
        });
    res.json(folders);
});

app.get('/api/chats/meta', requireUserOrGuest, (req, res) => {
    const ownerId = getOwnerId(req, res);
    let rows = [];
    if (req.user) {
        rows = db.prepare('SELECT folder_name, display_name, deleted_by_user, message_count, is_group, participants FROM chats WHERE user_id = ?').all(req.user.id);
    } else {
        rows = db.prepare('SELECT folder_name, display_name, message_count, is_group, participants FROM chats WHERE guest_id = ?').all(ownerId);
    }
    const map = {};
    for (const r of rows) {
        let parts = [];
        if (r.participants) {
            try { parts = JSON.parse(r.participants); } catch(e){}
        }
        map[r.folder_name] = {
            display_name: r.display_name || '',
            deleted_by_user: r.deleted_by_user || 0,
            message_count: r.message_count || 0,
            is_group: r.is_group || 0,
            participants: parts
        };
    }
    res.json(map);
});

app.get('/api/messages', requireUserOrGuest, async (req, res) => {
    const chatName = req.query.chat;
    if (!chatName) return res.status(400).json({ error: 'No chat specified' });

    const ownerId = getOwnerId(req, res);
    const myDir = userDir(ownerId);
    const chatDir = path.join(myDir, chatName);
    if (!path.normalize(chatDir).startsWith(myDir)) {
        return res.status(403).json({ error: 'Invalid path' });
    }

    try {
        const result = await getMessages(chatDir);
        res.json(result.messages);
    } catch (err) {
        if (err.code === 'NO_CHAT_FILE') return res.status(404).json({ error: 'Chat file not found' });
        console.error('Messages error:', err);
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/upload', (req, res, next) => {
    upload.array('files')(req, res, err => {
        if (err) {
            if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: 'File too large — max 500 MB' });
            return res.status(400).json({ error: err.message || 'Upload error' });
        }
        next();
    });
}, handleUpload);

app.delete('/api/chats/:name', requireUser, (req, res) => {
    const myDir = userDir(req.user.id);
    const chatDir = path.join(myDir, req.params.name);
    if (!path.normalize(chatDir).startsWith(myDir)) return res.status(403).json({ error: 'Invalid path' });
    if (!fs.existsSync(chatDir)) return res.status(404).json({ error: 'Chat not found' });
    // Soft delete — mark as deleted so admin still has access
    db.prepare('UPDATE chats SET deleted_by_user = 1 WHERE user_id = ? AND folder_name = ?')
        .run(req.user.id, req.params.name);
    res.json({ ok: true });
});

app.put('/api/chats/:name/rename', requireUser, (req, res) => {
    const { newName } = req.body || {};
    if (!newName || !newName.trim()) return res.status(400).json({ error: 'newName is required' });
    const cleanName = newName.trim();
    
    const existing = db.prepare('SELECT id FROM chats WHERE user_id = ? AND folder_name = ?').get(req.user.id, req.params.name);
    if (existing) {
        db.prepare('UPDATE chats SET display_name = ? WHERE user_id = ? AND folder_name = ?')
            .run(cleanName, req.user.id, req.params.name);
    } else {
        db.prepare('INSERT INTO chats (user_id, folder_name, display_name, created_at) VALUES (?, ?, ?, ?)')
            .run(req.user.id, req.params.name, cleanName, Date.now());
    }
    res.json({ ok: true, display_name: cleanName });
});

app.use('/api/ai', aiRouter);

app.use('/api/dodo', dodoRouter);
app.use('/api/global-chat', globalChatRouter);
app.use('/api/contact', contactRouter);

// ── Demo chat (landing page — no auth, IP-limited) ──
const { callLLM } = require('./server/llm');
const DEMO_LIMIT = 10;
const demoUsage = new Map(); // IP → { count, history[] }

const demoLimiter = rateLimit({
    windowMs: 60_000,
    max: 12,
    message: { error: 'Too fast. Wait a moment.' },
    validate: false,
});

function getDemoLimitAndUsage(req, sessionId) {
    let session = null;
    if (req.cookies && req.cookies.session_token) {
        session = getSession(req.cookies.session_token);
    }

    let key, limit;
    if (session) {
        const dateStr = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }).split(',')[0];
        key = `user_${session.id}_${dateStr}`;
        limit = 3; // 3 per day for logged in
    } else {
        key = `guest_${req.ip}_${sessionId || 'x'}`;
        limit = 2; // 2 once for guests
    }

    const usage = demoUsage.get(key) || { count: 0, history: [] };
    return { session, key, limit, usage };
}

app.get('/api/demo-chat/status', (req, res) => {
    const { sessionId } = req.query || {};
    const { limit, usage } = getDemoLimitAndUsage(req, sessionId);
    res.json({ remaining: Math.max(0, limit - usage.count), limit });
});

app.post('/api/demo-chat', demoLimiter, async (req, res) => {
    const { message, sessionId } = req.body || {};
    if (!message || typeof message !== 'string' || message.trim().length === 0)
        return res.status(400).json({ error: 'message required' });
    if (message.length > 300)
        return res.status(400).json({ error: 'Message too long' });

    const { session, key, limit, usage } = getDemoLimitAndUsage(req, sessionId);

    if (usage.count >= limit) {
        return res.status(429).json({
            error: session ? 'Daily limit reached for demo chat. Check back tomorrow!' : 'Demo limit reached! Sign up for free to keep chatting.',
            remaining: 0,
            limit: limit,
        });
    }

    usage.count++;
    usage.history.push({ role: 'user', content: message.trim() });
    // Keep last 6 turns (12 messages)
    if (usage.history.length > 12) usage.history = usage.history.slice(-12);
    demoUsage.set(key, usage);

    // Cleanup old sessions
    if (demoUsage.size > 5000) {
        const entries = [...demoUsage.entries()];
        entries.slice(0, 2000).forEach(([k]) => demoUsage.delete(k));
    }

    const remaining = limit - usage.count;

    // SSE setup
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('X-Accel-Buffering', 'no');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    const send = (event, data) => {
        res.write(`event: ${event}\n`);
        res.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    send('start', { remaining });

    const nowIST = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: true, weekday: 'long', day: 'numeric', month: 'long' });
    const systemPrompt = `You are "Maa" — a loving Indian mother chatting with her child (Beta) on WhatsApp.

CURRENT TIME (IST): ${nowIST}. If Beta asks the time/date, answer with THIS exact time — never guess.

PERSONALITY:
- You are warm, caring, slightly dramatic, always worried about food and health
- You text in Hinglish (mix of Hindi and English) — mostly Hindi
- Short messages: 1-3 lines max, like real WhatsApp
- You use emojis sparingly but lovingly: 🙏 😊 ❤️ 😘 🤗
- You call them "beta", "babu", "baccha"
- You always ask about food: "khana khaya?", "pani piyo", "dal chawal kha lo"
- Typical mom behaviors: asking about health, sleep, weather, studies/job
- Sometimes send blessings: "Bhagwan tumhe khush rakhe" 🙏
- You get dramatic about small things: "tum toh mujhe bhool hi gaye" if they haven't texted
- You type casually — no perfect grammar, sometimes skip words like real texting

RULES:
1. NEVER break character. You ARE Maa.
2. NEVER say you are AI or a chatbot.
3. Keep responses SHORT — 1-3 lines. Real WhatsApp style.
4. Respond in Hinglish (primarily Hindi with some English words).
5. Be natural, warm, and motherly.`;

    const abortController = new AbortController();
    req.on('close', () => abortController.abort());

    let fullText = '';
    try {
        await callLLM({
            feature: 'chat',
            messages: usage.history,
            systemPrompt,
            userId: null,
            signal: abortController.signal,
            onToken: (token) => {
                fullText += token;
                send('token', { text: token });
            },
        });

        usage.history.push({ role: 'assistant', content: fullText });
        if (usage.history.length > 12) usage.history = usage.history.slice(-12);
        demoUsage.set(key, usage);

        send('done', { remaining });
    } catch (err) {
        console.error('Demo chat error:', err.message);
        send('error', { message: 'AI is taking a break. Try again!' });
    } finally {
        res.end();
    }
});

// ─────────────────────────────────────────────
// DM REST API
// ─────────────────────────────────────────────

// Search user by email (exact match, privacy: only returns id + display_name + avatar_url)
app.get('/api/dm/search', requireUser, (req, res) => {
    const email = (req.query.email || '').toLowerCase().trim();
    if (!email) return res.status(400).json({ error: 'email required' });
    if (email === req.user.email) return res.status(400).json({ error: 'That\'s you!' });

    const found = db.prepare(
        'SELECT id, display_name, avatar_url, email FROM users WHERE LOWER(email) = ?'
    ).get(email);
    if (!found) return res.json({ user: null });

    res.json({
        user: {
            id: found.id,
            display_name: found.display_name || found.email.split('@')[0],
            avatar_url: found.avatar_url,
            // email intentionally NOT returned — privacy: only you know the email you searched
        },
    });
});

// ─────────────────────────────────────────────
// DM Presence & Real-time State Store
// ─────────────────────────────────────────────
const onlineUsers = new Map(); // userId → Set of socketIds
app.locals.onlineUsers = onlineUsers;

// Get or create a DM conversation with another user
app.post('/api/dm/conversations', requireUser, (req, res) => {
    const otherId = Number(req.body.user_id);
    if (!otherId || otherId === req.user.id) return res.status(400).json({ error: 'invalid user_id' });

    const other = db.prepare('SELECT id, display_name, avatar_url, email FROM users WHERE id = ?').get(otherId);
    if (!other) return res.status(404).json({ error: 'User not found' });

    // Canonical order: smaller id = user_a
    const [a, b] = req.user.id < otherId ? [req.user.id, otherId] : [otherId, req.user.id];

    db.prepare(
        'INSERT OR IGNORE INTO dm_conversations (user_a, user_b, created_at) VALUES (?, ?, ?)'
    ).run(a, b, Date.now());

    const conv = db.prepare(
        'SELECT id FROM dm_conversations WHERE user_a = ? AND user_b = ?'
    ).get(a, b);

    const nickRow = db.prepare('SELECT nickname FROM dm_contact_nicknames WHERE user_id = ? AND contact_id = ?').get(req.user.id, otherId);
    const originalName = other.display_name || other.email.split('@')[0];

    res.json({
        conv_id: conv.id,
        other: {
            id: other.id,
            display_name: nickRow ? nickRow.nickname : originalName,
            original_display_name: originalName,
            email: other.email,
            avatar_url: other.avatar_url,
        },
    });
});

// List all DM conversations for current user
app.get('/api/dm/conversations', requireUser, (req, res) => {
    const rows = db.prepare(`
        SELECT
            dc.id AS conv_id,
            CASE WHEN dc.user_a = ? THEN dc.user_b ELSE dc.user_a END AS other_id,
            (SELECT body FROM dm_messages WHERE conv_id = dc.id ORDER BY id DESC LIMIT 1) AS last_msg,
            (SELECT created_at FROM dm_messages WHERE conv_id = dc.id ORDER BY id DESC LIMIT 1) AS last_at,
            (SELECT COUNT(*) FROM dm_messages WHERE conv_id = dc.id AND sender_id != ? AND read_at IS NULL) AS unread
        FROM dm_conversations dc
        WHERE dc.user_a = ? OR dc.user_b = ?
        ORDER BY last_at DESC NULLS LAST
    `).all(req.user.id, req.user.id, req.user.id, req.user.id);

    const result = rows.map(r => {
        const u = db.prepare('SELECT id, display_name, avatar_url, email FROM users WHERE id = ?').get(r.other_id);
        const nickRow = db.prepare('SELECT nickname FROM dm_contact_nicknames WHERE user_id = ? AND contact_id = ?').get(req.user.id, r.other_id);
        const originalName = u ? (u.display_name || u.email.split('@')[0]) : 'User';
        return {
            conv_id: r.conv_id,
            other: {
                id: u ? u.id : r.other_id,
                display_name: nickRow ? nickRow.nickname : originalName,
                original_display_name: originalName,
                email: u ? u.email : '',
                avatar_url: u ? u.avatar_url : null,
            },
            last_msg: r.last_msg || '',
            last_at: r.last_at || 0,
            unread: r.unread || 0,
        };
    });

    res.json(result);
});

// Set custom nickname for a contact
app.put('/api/dm/contacts/:contactId/nickname', requireUser, (req, res) => {
    const contactId = Number(req.params.contactId);
    const nickname = (req.body?.nickname || '').trim();
    const userId = req.user.id;

    if (!contactId) return res.status(400).json({ error: 'Invalid contactId' });

    const contact = db.prepare('SELECT display_name, email FROM users WHERE id = ?').get(contactId);
    if (!contact) return res.status(404).json({ error: 'Contact not found' });
    const originalName = contact.display_name || contact.email.split('@')[0];

    if (!nickname) {
        db.prepare('DELETE FROM dm_contact_nicknames WHERE user_id = ? AND contact_id = ?').run(userId, contactId);
        return res.json({ ok: true, nickname: null, display_name: originalName, original_display_name: originalName });
    }

    db.prepare(`
        INSERT INTO dm_contact_nicknames (user_id, contact_id, nickname, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(user_id, contact_id) DO UPDATE SET nickname = excluded.nickname, updated_at = excluded.updated_at
    `).run(userId, contactId, nickname, Date.now());

    res.json({ ok: true, nickname, display_name: nickname, original_display_name: originalName });
});

// Get messages for a conversation (paginated, newest first)
// Clear all messages in a DM conversation (soft-delete for this user only)
app.delete('/api/dm/conversations/:id/messages', requireUser, (req, res) => {
    const convId = Number(req.params.id);
    const conv = db.prepare(
        'SELECT * FROM dm_conversations WHERE id = ? AND (user_a = ? OR user_b = ?)'
    ).get(convId, req.user.id, req.user.id);
    if (!conv) return res.status(403).json({ error: 'Not your conversation' });

    // Hard delete all messages in this conversation
    db.prepare('DELETE FROM dm_messages WHERE conv_id = ?').run(convId);
    res.json({ ok: true });
});

// Delete own DM message
app.delete('/api/dm/messages/:id', requireUser, (req, res) => {
    const msgId = Number(req.params.id);
    const msg = db.prepare('SELECT * FROM dm_messages WHERE id = ?').get(msgId);
    if (!msg) return res.status(404).json({ error: 'Not found' });
    if (msg.sender_id !== req.user.id) return res.status(403).json({ error: 'Not your message' });

    db.prepare('UPDATE dm_messages SET body = ?, type = ? WHERE id = ?')
      .run('This message was deleted', 'deleted', msgId);

    // Notify both users via socket
    const conv = db.prepare('SELECT * FROM dm_conversations WHERE id = ?').get(msg.conv_id);
    if (conv) {
        const otherId = conv.user_a === req.user.id ? conv.user_b : conv.user_a;
        [req.user.id, otherId].forEach(uid => {
            const sockets = onlineUsers.get(uid);
            if (sockets) sockets.forEach(sid => io.to(sid).emit('dm:deleted', { msg_id: msgId, conv_id: msg.conv_id }));
        });
    }
    res.json({ ok: true });
});

// HTTP fallback for sending a message (used when socket.io isn't connected yet)
app.post('/api/dm/upload', requireUser, dmUpload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const url = `/uploads/dm/${req.file.filename}`;
    res.json({ url });
});

app.post('/api/dm/conversations/:id/messages', requireUser, (req, res) => {
    const convId = Number(req.params.id);
    const body   = (req.body?.body || '').trim();
    const type   = req.body?.type || 'text';
    const media_url = req.body?.media_url || null;

    if (!body && !media_url) return res.status(400).json({ error: 'Empty message' });

    if (body && countWords(body) > 300) {
        return res.status(400).json({ error: 'Message exceeds limit (max 300 words). Please shorten your message to prevent server slowdown.' });
    }

    const burstCheck = checkBurstLimit(`dm_${req.user.id}`);
    if (!burstCheck.allowed) {
        return res.status(429).json({ error: burstCheck.error });
    }

    const conv = db.prepare(
        'SELECT * FROM dm_conversations WHERE id = ? AND (user_a = ? OR user_b = ?)'
    ).get(convId, req.user.id, req.user.id);
    if (!conv) return res.status(403).json({ error: 'Not your conversation' });

    const now    = Date.now();
    const result = db.prepare(
        'INSERT INTO dm_messages (conv_id, sender_id, body, type, media_url, created_at, read_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).run(convId, req.user.id, body, type, media_url, now, now);

    const msg = {
        id: result.lastInsertRowid, conv_id: convId,
        sender_id: req.user.id, body, type, media_url: media_url,
        created_at: now, read_at: now,
        display_name: req.user.display_name || req.user.email.split('@')[0],
        avatar_url: req.user.avatar_url,
    };

    // Push via socket.io if the other user is online
    const otherId = conv.user_a === req.user.id ? conv.user_b : conv.user_a;
    [req.user.id, otherId].forEach(uid => {
        const sockets = onlineUsers.get(uid);
        if (sockets) sockets.forEach(sid => io.to(sid).emit('dm:message', msg));
    });

    res.json(msg);
});

app.get('/api/dm/conversations/:id/messages', requireUser, (req, res) => {
    const convId = Number(req.params.id);
    const conv = db.prepare(
        'SELECT * FROM dm_conversations WHERE id = ? AND (user_a = ? OR user_b = ?)'
    ).get(convId, req.user.id, req.user.id);
    if (!conv) return res.status(403).json({ error: 'Not your conversation' });

    const before = Number(req.query.before) || Date.now() + 1000;
    const after  = Number(req.query.after)  || 0;
    const msgs = db.prepare(`
        SELECT dm.*, u.display_name, u.avatar_url, u.email
        FROM dm_messages dm
        JOIN users u ON u.id = dm.sender_id
        WHERE dm.conv_id = ? AND dm.created_at < ? AND dm.created_at > ?
        ORDER BY dm.created_at DESC
        LIMIT 40
    `).all(convId, before, after);

    // Mark messages as read
    const now = Date.now();
    const updateResult = db.prepare(
        'UPDATE dm_messages SET read_at = ? WHERE conv_id = ? AND sender_id != ? AND read_at IS NULL'
    ).run(now, convId, req.user.id);

    if (updateResult.changes > 0) {
        const otherId = conv.user_a === req.user.id ? conv.user_b : conv.user_a;
        const sockets = onlineUsers.get(otherId);
        if (sockets) {
            sockets.forEach(sid => io.to(sid).emit('dm:read', { conv_id: convId }));
        }
    }

    // Include my_id so frontend knows which side is "me" — guaranteed correct
    res.json({ messages: msgs.reverse(), my_id: req.user.id });
});

// DM Presence API endpoint
app.get('/api/dm/presence', requireUser, (req, res) => {
    const onlineIds = Array.from(onlineUsers.keys()).map(Number);
    res.json({ online_user_ids: onlineIds });
});

// ─────────────────────────────────────────────
// Socket.IO — real-time DM
// ─────────────────────────────────────────────

io.use((socket, next) => {
    // Authenticate via session cookie (same cookie as HTTP)
    const req = socket.request;
    cookieParser()(req, {}, () => {});
    authMiddleware(req, {}, () => {});
    if (!req.user) return next(new Error('Unauthorized'));
    socket.user = req.user;
    next();
});

io.on('connection', (socket) => {
    const uid = Number(socket.user.id);
    const isFirstConnection = !onlineUsers.has(uid) || onlineUsers.get(uid).size === 0;
    if (!onlineUsers.has(uid)) onlineUsers.set(uid, new Set());
    onlineUsers.get(uid).add(socket.id);

    // Send immediate initial presence list to this newly connected user
    const currentOnlineIds = Array.from(onlineUsers.keys()).map(Number);
    socket.emit('presence:init', { online_user_ids: currentOnlineIds });

    // Broadcast user:online to everyone else if this is their first active socket
    if (isFirstConnection) {
        io.emit('user:online', { user_id: uid });
    }

    socket.on('dm:get_presence', () => {
        socket.emit('presence:init', { online_user_ids: Array.from(onlineUsers.keys()).map(Number) });
    });

    socket.on('dm:send', (data) => {
        const { conv_id, body } = data;
        const type = data.type || 'text';
        const media_url = data.media_url || null;
        
        if (!conv_id) return;
        if ((!body || !body.trim()) && !media_url) return;

        if (body && countWords(body) > 300) {
            return socket.emit('dm:error', { error: 'Message exceeds limit (max 300 words). Please shorten your message to prevent server slowdown.' });
        }

        const burstCheck = checkBurstLimit(`dm_${uid}`);
        if (!burstCheck.allowed) {
            return socket.emit('dm:error', { error: burstCheck.error });
        }

        // Verify sender is part of this conversation
        const conv = db.prepare(
            'SELECT * FROM dm_conversations WHERE id = ? AND (user_a = ? OR user_b = ?)'
        ).get(conv_id, uid, uid);
        if (!conv) return;

        const now = Date.now();
        const result = db.prepare(
            'INSERT INTO dm_messages (conv_id, sender_id, body, type, media_url, created_at) VALUES (?, ?, ?, ?, ?, ?)'
        ).run(conv_id, uid, body ? body.trim() : '', type, media_url, now);

        const msg = {
            id: result.lastInsertRowid,
            conv_id,
            sender_id: uid,
            body: body ? body.trim() : '',
            type,
            media_url,
            created_at: now,
            read_at: null,
            display_name: socket.user.display_name || socket.user.email.split('@')[0],
            avatar_url: socket.user.avatar_url,
        };

        // Send to both users (all their open sockets)
        const otherId = conv.user_a === uid ? conv.user_b : conv.user_a;
        [uid, otherId].forEach(targetId => {
            const sockets = onlineUsers.get(targetId);
            if (sockets) sockets.forEach(sid => io.to(sid).emit('dm:message', msg));
        });

    });

    socket.on('dm:mark_read', ({ conv_id }) => {
        const conv = db.prepare(
            'SELECT * FROM dm_conversations WHERE id = ? AND (user_a = ? OR user_b = ?)'
        ).get(conv_id, uid, uid);
        if (!conv) return;

        const now = Date.now();
        const updateResult = db.prepare(
            'UPDATE dm_messages SET read_at = ? WHERE conv_id = ? AND sender_id != ? AND read_at IS NULL'
        ).run(now, conv_id, uid);

        if (updateResult.changes > 0) {
            const otherId = conv.user_a === uid ? conv.user_b : conv.user_a;
            const sockets = onlineUsers.get(otherId);
            if (sockets) {
                sockets.forEach(sid => io.to(sid).emit('dm:read', { conv_id }));
            }
        }
    });

    socket.on('dm:typing', ({ conv_id, typing }) => {
        const conv = db.prepare(
            'SELECT * FROM dm_conversations WHERE id = ? AND (user_a = ? OR user_b = ?)'
        ).get(conv_id, uid, uid);
        if (!conv) return;
        const otherId = conv.user_a === uid ? conv.user_b : conv.user_a;
        const sockets = onlineUsers.get(otherId);
        if (sockets) sockets.forEach(sid => io.to(sid).emit('dm:typing', { conv_id, user_id: uid, typing }));
    });

    socket.on('disconnect', () => {
        const set = onlineUsers.get(uid);
        if (set) {
            set.delete(socket.id);
            if (set.size === 0) {
                onlineUsers.delete(uid);
                io.emit('user:offline', { user_id: uid });
            }
        }
    });
});

// Contact form (no auth required)
app.post('/api/contact', contactLimiter, (req, res) => {
    const { name, email, topic, message } = req.body || {};
    if (!email || !message) return res.status(400).json({ error: 'Missing fields' });
    // Log to console (admin can see in pm2 logs) — extend with email if needed
    console.log(`[CONTACT] ${new Date().toISOString()} | ${topic || 'General'} | ${email} (${name}): ${message}`);
    res.json({ ok: true });
});

// 404 fallback (must be last)
app.use((req, res) => {
    if (req.path.startsWith('/api/')) {
        return res.status(404).json({ error: 'Not found' });
    }
    res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
});

httpServer.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
    if (!process.env.ENCRYPTION_SECRET) {
        console.warn('⚠️  ENCRYPTION_SECRET missing in .env — providers admin pages will fail');
    }
    if (!process.env.ADMIN_EMAIL) {
        console.warn('⚠️  ADMIN_EMAIL not set — signup with that email to become admin');
    }
});
